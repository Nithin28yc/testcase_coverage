import os
import openai
import pandas as pd

# Set your OpenAI API key
openai.api_type = "###API_TYPE###"
openai.api_base = "###API_BASE###"
openai.api_version = "###API_VERSION###"
openai.api_key = "###API_KEY###"

code_snippet=''
features=''
# with open('C:\\Users\\keerthana.vijaykumar\\OneDrive - Accenture\\Desktop\\poc-tasks\\htmltojson\\testcoverage\\featuregenerated.txt', 'r') as file:
    # code_snippet=file.read()
path = 'onlinebookstore-master\src\main\java\servlets'
folder_path = os.listdir(path)
for file_name in folder_path:
    if file_name.endswith(".java"):
        with open(path+'\\'+file_name, 'r') as file:
            code_snippet=file.read()
        response = openai.Completion.create(
                    engine="devops",
                    prompt=f"Given the following code:\n\n{code_snippet}\n\nWrite the feature list in bullet points:\n",
                    max_tokens=2000,  # Adjust the number of tokens as needed
                    temperature=0,  # Adjust the temperature for creativity
            )
        features = response.choices[0].text

        # print(features)
        # with open('featuregenerated.txt', 'a') as file:
        #     file.write(test_scenarios_and_cases)

response = openai.Completion.create(
    engine="devops",
   # prompt=f"From the following list:\n\n{features}\n\nGive only highlevel Features in proper json format:\n",
    prompt=f"""Please generate a JSON list from {features} with only the following information:
               Feature: 'Name of the feature'""",
    max_tokens=600,  # Adjust the number of tokens as needed
    temperature=0,  # Adjust the temperature for creativity
)
features_gen = response.choices[0].text
print(features_gen)

with open('feature_derived_from_code_new.json', 'w') as file:
    file.write(features_gen)

with open('feature_derived_from_code_new.json', encoding='utf-8') as inputfile:
    df = pd.read_json(inputfile)

df.to_csv('test_coverage_new.csv', encoding='utf-8', index=False)

print('successfully executed')
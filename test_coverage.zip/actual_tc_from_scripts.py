import csv
import os
import re
import openai
import pandas as pd

# Set your OpenAI API key
openai.api_type = "###API_TYPE###"
openai.api_base = "###API_BASE###"
openai.api_version = "###API_VERSION###"
openai.api_key = "###API_KEY###"

search_directory = r'onlinebookstore-master\meaning'
folder_path = os.listdir(search_directory)
features_list = []

with open('test_coverage_new.csv', newline='') as file:
    csv_reader = csv.DictReader(file)   
    for row in csv_reader:
        features_list.append(row['Feature'])

# Function to search for files
def search_files(directory, keyword):
    result = []
    for file in folder_path:
        if file.endswith('.java'):
            file_wo_ext = file.replace('.java','')
            if re.match(keyword, file_wo_ext, re.IGNORECASE) or file_wo_ext in keyword or meancomp(file_wo_ext, keyword):
                # result.append(file_wo_ext)
                with open(search_directory+'\\'+file, 'r') as file:
                    code_snippet=file.read()
                response = openai.Completion.create(
                    engine="devops",
                    prompt=f"Give the list of covered test cases without test steps from the {code_snippet}\n\n",
                    max_tokens=700,  # Adjust the number of tokens as needed
                    temperature=0.7,  # Adjust the temperature for creativity
                )
                result.append(response.choices[0].text)
                # print(result)
    return result


def meancomp(filewithex, features):
    filemeaning_response = openai.Completion.create(
                    engine="devops",
                    prompt=f"Generate the meaning of {filewithex} in plain language \n",
                    max_tokens=70,  # Adjust the number of tokens as needed
                    temperature=0.3,  # Adjust the temperature for creativity
            )
    resp = filemeaning_response.choices[0].text
 #   print("filenme meaning"+resp+"\n")

    featuremeaning_response = openai.Completion.create(
                    engine="devops",
                    prompt=f"Generate the meaning {features} in plain language\n",
                    max_tokens=70,  # Adjust the number of tokens as needed
                    temperature=0.3,  # Adjust the temperature for creativity
    )
    resp1 = featuremeaning_response.choices[0].text
#    print("featurename meaning"+resp1 + "\n")

    meaningcomp_response = openai.Completion.create(
                engine="devops",
                prompt=f"Verify whether the both meaning of {filewithex} and {features} is coneying the same meaning in plain language and give the response in Yes or No",
                temperature=0.615,
                max_tokens=300,
            )
    respcomp = meaningcomp_response.choices[0].text

    if "Yes" in respcomp or "YES" in respcomp or "yes" in respcomp:
        print("Meaning compare:"+ filewithex + features +"\n" +  respcomp)
        return True
    return False


file_results = {}
for feature in features_list:
    # print(re.sub(r'\s+', '', keyword))
    matches = search_files(search_directory, re.sub(r'\s+', '', feature))
    if matches:
        file_results[feature] = matches

print(file_results)

df = pd.read_csv('test_coverage_new.csv')
for index, row in df.iterrows():
    if row["Feature"] in file_results:
        df.at[index, "Actual Test Cases"] = str(file_results[row["Feature"]])
df.to_csv('test_coverage_new.csv', index=False)
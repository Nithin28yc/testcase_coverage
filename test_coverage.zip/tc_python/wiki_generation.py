import os
import openai
from docx import Document

# Set your OpenAI API key
openai.api_type = "azure"
openai.api_base = "https://genwizard-adm-brownfield.openai.azure.com"
openai.api_version = "2023-07-01-preview"
openai.api_key = "8df1223485e84c97a419cc93fa9ca1af"

# Setting the root path for the application source code folder
java_files=[]
root_path=r'C:\Users\nithin.y.c\OneDrive - Accenture\Documents\Code Coverage\ct_genai_testcoverage\onlinebookstore-master\src\main'  # need to be parameterised
for root, dirs, files in os.walk(root_path): 
    for file in files:
        if file.endswith(".java"):
            java_files.append(os.path.join(root, file)) 

# Function for model,temp and response config:
def genai(prompt):
    messages = []
    messages.append({'role':'user','content':prompt})
    response = openai.ChatCompletion.create(
        engine="genwizard-adm-brownfield",  # Give the model name
        messages = messages,
        temperature=0,  # Adjust the temperature for creativity
    )
    result=response.choices[0].message['content']
    return result

# Function to generate the summary of the given files in root_path
def summarizer(java_files_list):
    summaries=''
    for file_name in java_files_list:
        with open(file_name, 'r') as file:
            code_snippet=file.read()    
        trunc_file=os.path.basename(file_name)
        messages = [] 
        prompt=f"""Summarize what the following code does from {trunc_file}.
        Here is the code:\n+{code_snippet}."""
        messages.append({'role':'user','content':prompt})
        response = openai.ChatCompletion.create(
            engine="genwizard-adm-brownfield",
            messages = messages,
            temperature=0.2,  # Adjust the temperature for creativity
        )
        result=response.choices[0].message['content']
        summaries=summaries+'\n'+trunc_file+':\n'+result
        #print(result)
    return summaries
summaries=summarizer(java_files)

# Function to get the 'overview' section of the wiki
def overview():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Output format:
        Give the Overview of the application in 80 words
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI      
overview_section = overview()

# Function to get the 'purpose of code' section of the wiki
def purpose():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Purpose of the code base in 80 words
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI      
purpose_section = purpose()

# Function to get the 'version and release note' section of the wiki
def version():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Versions and release notes
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI      
version_section = version()

intro = "Introduction"+'\n\n'+"• Overview of the application"+'\n\n'+overview_section+'\n\n'+"• Purpose of the code base"+'\n\n'+purpose_section+'\n\n'+"• Versions and release notes"+'\n\n'+version_section+'\n\n'
# print(intro)

# Function to get the 'Setting up the development environment' section of the wiki
def settingdev():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give Setting up the development environment if present
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI
gettingstarted_section = settingdev()

# Function to get the 'Installation guide' section of the wiki
def installationguide():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Installation guide if present
        \nHere are the summaries:\n{summaries}.
        """
        genAI = genai(prompt)
        return genAI
installationguide_section = installationguide()

# Function to get the 'dependency & confiuration' section of the wiki
def dependency():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Dependency & Configuration details in single paragraph
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI
dependency_section = dependency()

gettingstarted = "Getting Started"+'\n\n'+"• Setting up the development environment"+'\n\n'+gettingstarted_section+'\n\n'+"• Installation guide"+'\n\n'+installationguide_section+'\n\n'+"• Dependency & Configuration details"+'\n\n'+dependency_section+'\n\n'
# print(gettingstarted)

# Function to get the 'Requirements' section of the wiki
def requirements():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Requirements in 150 words
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI    
requirements_section = requirements()

# Function to get the 'License' section of the wiki
def license():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions. 
        Give the license information.
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI      
license_section = license()

# Function to get the 'Common setup' section of the wiki
def commonsetup():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Commonset up
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI      
commonsetup_section = commonsetup()

# Function to get the 'UserFLow' section of the wiki
def userflow():     # plantuml needs to be used to get user flow diagram
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions. Based on these give one example
    of how this application might work as a whole. Do not explain individual files with example but explain as an overall example.
    \nHere is the data:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI      
userflow_section = userflow()

req_lice_com_uf = "Requirements"+'\n\n'+requirements_section+'\n\n'+"License"+'\n\n'+license_section+'\n\n'+"Common Setup"+'\n\n'+commonsetup_section+'\n\n'+"User Flow"+'\n\n'+userflow_section+'\n\n'
# print(req_lice_com_uf)

# Function to get the 'Architecture overview' section of the wiki
def architecture_overview():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Overview of System Architecture in 100 words
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI      
architecture_overview_section = architecture_overview()

# Function to get the 'High level diagram' section of the wiki
def highlevel_diagram():    # plantuml need to used to get the diagram
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the overall content in 100 words for High-level component Diagram    
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI       
highlevel_diagram_section = highlevel_diagram()

# Function to get the 'Database overview' section of the wiki
def database_overview():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Database schema overview in 100 words
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI       
database_overview_section = database_overview()

Arch_overview = "Architecture Overview"+'\n\n'+"• Overview of System Architecture"+"\n\n"+architecture_overview_section+"\n\n"+"• High-level component Diagram"+"\n\n"+highlevel_diagram_section+"\n\n"+"• Database schema overview"+"\n\n"+database_overview_section+'\n\n' 
# print(Arch_overview)

# Function to get the 'Core features and functionalities' section of the wiki
def features_func():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Core features and functionalities 
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI
functionality_section = features_func()

# Function to get the 'roles and permission' section of the wiki
def roles():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the User roles and permissions
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI  
roles_section = roles()

# Function to get the 'usecase scenario' section of the wiki
def usecase_scenario():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Use case scenarios with examples
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI        
usecase_scenario_section = usecase_scenario()  

functionality = "Functionality"+'\n\n'+"• Core features and functionalities"+'\n\n'+functionality_section+'\n\n'+" • User roles and permissions"+'\n\n'+roles_section+'\n\n'+"• Use case scenarios with examples"+'\n\n'+usecase_scenario_section+'\n\n'
# print(functionality)

# Function to get the 'Business rules and workflows' section of the wiki
def business_rules_workflows():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Business rules and workflows in 200 words
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI
business_rules_workflows_section = business_rules_workflows()

# Function to get the 'External APIs or integrations' section of the wiki
def external_api():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the External APIs or integrations
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI
external_api_section = external_api()
    
# Function to get the 'Data flow and processing' section of the wiki
def dataflow():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Data flow and processing in 100 words
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI
dataflow_section = dataflow()

business_logic = "Business Logic"+'\n\n'+"• Business rules and workflows"+'\n\n'+business_rules_workflows_section+'\n\n'+"• External APIs or integrations"+'\n\n'+external_api_section+'\n\n'+"• Data flow and processing"+'\n\n'+dataflow_section+'\n\n'
#print(business_logic)

# Function to get the 'Sequence Diagram' section of the wiki
def sequence_diagram():    # output ned to be sent to plantuml to get diagram
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the content to get the Sequence Diagram
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI
sequence_diagram_section = sequence_diagram()

# Function to get the 'Class Diagram' section of the wiki
def class_diagram():  # output ned to be sent to plantuml to get diagram
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the content to get the Class Diagram
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI
class_diagram_section = class_diagram()

# Function to get the 'External Packages Or Imports' section of the wiki
def external_packages():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the External Packages Or Imports used as an overall.
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI
external_packages_section = external_packages()

technical_architecture = "Technical Architecture"+'\n\n'+"• Sequence Diagram"+'\n\n'+sequence_diagram_section+'\n\n'+"• Class Diagram"+'\n\n'+class_diagram_section+'\n\n'+"• External Packages Or Imports"+'\n\n'+external_packages_section+'\n\n'
#print(technical_architecture)

# Function to get the 'Overview of deployment strategies' section of the wiki
def deploy_architecture():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Overview of deployment strategies (e.g., monolithic, microservices)
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI
deploy_architecture_section = deploy_architecture()

# Function to get the 'Scalability and redundancy considerations' section of the wiki
def scalability():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Scalability and redundancy considerations within 100 words
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI
scalability_section = scalability()

# Function to get the 'Deployment diagrams' section of the wiki
def deployment_diagram():  # output ned to be sent to plantuml to get diagram
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the content for Deployment diagrams in 100 words
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI
deployment_diagram_section = deployment_diagram()

deployarchitecture = "Deployment Architecture"+'\n\n'+"• Overview of deployment strategies (e.g., monolithic, microservices)"+"'\n\n'"+deploy_architecture_section+'\n\n'+"• Scalability and redundancy considerations"+'\n\n'+scalability_section+'\n\n'+"• Deployment diagrams"+'\n\n'+deployment_diagram_section+'\n\n'
#print(deployarchitecture)

# Function to get the 'Authentication and authorization mechanisms' section of the wiki
def security_architecture():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Authentication and authorization mechanisms.
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI        
security_architecture_section = security_architecture()

# Function to get the 'Encryption methods' section of the wiki
def encryption_methods():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Encryption methods used.
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI       
encryption_methods_section = encryption_methods()

# Function to get the 'Threat models and security protocols' section of the wiki
def threat_models():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a text containing various files and their descriptions.
        Give the Threat models and security protocols used.
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI       
threat_models_section = threat_models()

securityarchitecture="Security Architecture"+'\n\n'+"• Authentication and authorization mechanisms"+'\n\n'+security_architecture_section+'\n\n'+"• Encryption methods used"+'\n\n'+encryption_methods_section+'\n\n'+"• Threat models and security protocols"+'\n\n'+threat_models_section+'\n\n'
#print(securityarchitecture)

# Function to get the 'Caching strategies employed' section of the wiki
def caching():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions. 
        Give the Caching strategies employed if present
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI      
caching_section = caching()

# Function to get the 'Load balancing and optimization techniques' section of the wiki
def load_balancing():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions.
        Give the Load balancing and optimization techniques if present
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI        
load_balancing_section = load_balancing()

# Function to get the 'Performance testing results and benchmarks' section of the wiki
def performance_testing():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions.
        Give the Performance testing results and benchmarks if present
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI        
performance_testing_section = performance_testing()

performance_architecture = "Performance Architecture"+'\n\n'+"• Caching strategies employed"+'\n\n'+caching_section+'\n\n'+"• Load balancing and optimization techniques"+'\n\n'+load_balancing_section+'\n\n'+"• Performance testing results and benchmarks"+'\n\n'+performance_testing_section+'\n\n'
# print(performance_architecture)

# Function to get the 'Programming languages and frameworks' section of the wiki
def programming():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions.
        Give the Programming languages and frameworks used if present
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI      
programming_section = programming()

# Function to get the 'Third-party libraries and dependencies' section of the wiki
def libraries():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions.
        Give the Third-party libraries and dependencies if present
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI        
libraries_section = libraries()

# Function to get the 'Deployment strategies' section of the wiki
def deployment_strategies():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions. 
        Give the Deployment strategies details if present
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI    
deployment_strategies_section = deployment_strategies()

technical_stack="Technical Stack"+'\n\n'+"• Programming languages and frameworks used"+'\n\n'+programming_section+'\n\n'+"• Third-party libraries and dependencies"+'\n\n'+libraries_section+'\n\n'+"• Deployment strategies"+'\n\n'+deployment_strategies_section+'\n\n'
# print(technical_stack)

# Function to get the 'Source Code Review' section of the wiki
def source_code_review():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions.
        Give the Source Code Review
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI
source_code_review_section = source_code_review()
#print(source_code_review_section)

# Function to get the 'Directory structure' section of the wiki
def directory():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions.
        Give the Directory structure
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI      
directory_section = directory()

# Function to get the 'Module breakdown and responsibilities' section of the wiki
def module_breakdown():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions.
        Give the Module breakdown and responsibilities 
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI       
module_breakdown_section = module_breakdown()

# Function to get the 'Key files and their purposes' section of the wiki
def key_files():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions.
        Give only the Key files and their purposes       
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI
key_files_section = key_files()

# Function to get the 'Detailed explanation of code' section of the wiki
def detailed_explanation_code():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions. 
        Give the Detailed explanation of code for each file
        Output Format:
        -Structure      
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI     
detailed_explanation_code_section = detailed_explanation_code()

codebase_structure = "Codebase Structure"+'\n\n'+"•Directory structure"+'\n\n'+directory_section+'\n\n'+"•	Module breakdown and responsibilities"+'\n\n'+module_breakdown_section+'\n\n'+"• Key files and their purposes"+'\n\n'+key_files_section+'\n\n'+"• Detailed explanation of code "+'\n\n'+detailed_explanation_code_section+'\n\n'
# print(codebase_structure)

# Function to get the 'Coding conventions and standards' section of the wiki
def coding_standards():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions.
        Give the Coding conventions and standards if present
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI      
coding_standards_section = coding_standards()

# Function to get the 'Version control practices' section of the wiki
def version_control():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions. 
        Give the Version control practices if present
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI       
version_control_section = version_control()

development_guidelines = "Developement Guidelines"+'\n\n'+"• Coding conventions and standards"+'\n\n'+coding_standards_section+'\n\n'+"• Version control practices"+'\n\n'+version_control_section+'\n\n'
# print(development_guidelines)

# Function to get the 'Description of testing frameworks' section of the wiki
def testing_framework():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions.
        Give the Description of testing frameworks only if present.
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI        
testing_framework_section = testing_framework()

# Function to get the 'Examples of testing code and suites' section of the wiki
def eaxmple_testing_framework():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions.
        Give the Examples of testing code and suites only if present.
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI       
eaxmple_testing_framework_section = eaxmple_testing_framework()

# Function to get the 'Overview of testing methodologies' section of the wiki
def testing_methodologies():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions.
        Give the Overview of testing methodologies used only if present.
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI       
testing_methodologies_section = testing_methodologies()

# Function to get the 'Coverage reports and metrics' section of the wiki
def coverage_reports():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions. 
        Give the Coverage reports and metrics only if present.
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI       
coverage_reports_section = coverage_reports()

# Function to get the 'Areas covered by different types of tests' section of the wiki
def areas_covered():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions. 
        Give the Areas covered by different types of tests only if present.
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI       
areas_covered_section = areas_covered()

# Function to get the 'Automation scripts for testing and deployment' section of the wiki
def automation_scripts():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions.
        Give the Automation scripts for testing and deployment only if present.
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI        
automation_scripts_section = automation_scripts()

testingframework="Testing Framework"+'\n\n'+"• Description of testing frameworks"+'\n\n'+testing_framework_section+'\n\n'+"• Examples of testing code and suites"+'\n\n'+eaxmple_testing_framework_section+'\n\n'+"• Overview of testing methodologies used"+'\n\n'+testing_methodologies_section+'\n\n'+"• Coverage reports and metrics"+'\n\n'+coverage_reports_section+'\n\n'+"•	Areas covered by different types of tests"+'\n\n'+areas_covered_section+'\n\n'+"• Automation scripts for testing and deployment"+'\n\n'+automation_scripts_section+'\n\n'
# print(testingframework)

# Function to get the 'Tools and Platforms' section of the wiki
def tools():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions. 
        Give the Tools and Platforms used if exists . 
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI        
tools_section = tools()

# Function to get the 'Pipeline Configuration' section of the wiki
def pipeline_configuration():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions. 
        Give the Pipeline Configuration details if exists. 
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI        
pipeline_configuration_section = pipeline_configuration()

# Function to get the 'Monitoring and Optimization' section of the wiki
def monitoring():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions. 
        Give the Monitoring and Optimization details if exists. 
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI       
monitoring_section = monitoring()

cicd = "Continuous Integration/Continuous Deployment (CI/CD)"+'\n\n'+"•	Tools and Platforms"+'\n\n'+tools_section+'\n\n'+"• Pipeline Configuration"+'\n\n'+pipeline_configuration_section+'\n\n'+"• Monitoring and Optimization"+'\n\n'+monitoring_section+'\n\n'
# print(cicd)

# Function to get the 'Common issues and solutions' section of the wiki
def troubleshooting():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions.
        Give the Common issues and solutions if these exists.
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI
issues_solution_section = troubleshooting()

# Function to get the 'FAQs related to development and deployment' section of the wiki
def faqs():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions. 
        Give the FAQs related to development and deployment with answers also
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI       
faqs_section = faqs()

# Function to get the 'Troubleshooting steps for specific scenarios' section of the wiki
def troubleshooting_steps():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions.
        Give the Troubleshooting steps for specific scenarios if these exists.
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI       
troubleshooting_steps_section = troubleshooting_steps()

troubleshoot="Troubleshooting and FAQs"+'\n\n'+"•Common issues and solutions"+'\n\n'+issues_solution_section+'\n\n'+"•FAQs related to development and deployment"+'\n\n'+faqs_section+'\n\n'+"•Troubleshooting steps for specific scenarios"+'\n\n'+troubleshooting_steps_section+'\n\n'
# print(troubleshoot)

# Function to get the 'Improvements' section of the wiki
def challenges(java_files_list):
    for file_name in java_files_list:
        with open(file_name, 'r') as file:
            code_snippet=file.read()    
        trunc_file=os.path.basename(file_name)
    messages = []
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is code from {trunc_file}. Give heading as only 'Improvements' for the below. Based on the code,
        Generate a table format of Challenges and Improvements on the code with the following columns: "Improvements," "Files," and "Additional Notes"
            \nHere is the code:\n{code_snippet}
        """
        genAI = genai(prompt)
    return genAI
improvements_section=challenges(java_files)+'\n\n'
# print(improvements_section)

# Function to get the 'Links to relevant documentation' section of the wiki
def links():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions.
        Give the Links to relevant documentation.
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI       
links_section = links()

# Function to get the 'Useful external resources' section of the wiki
def external_resources():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions. 
        Give the Useful external resources.
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI       
external_resources_section = external_resources()

# Function to get the 'Contact information for key team members' section of the wiki
def contact_info():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given is code containing various files and their descriptions. 
        Give the Contact information for key team members.
        \nHere are the summaries:\n{summaries}
        """
        genAI = genai(prompt)
        return genAI       
contact_info_section = contact_info()

references = "Resources and References"+'\n\n'+"•Links to relevant documentation"+'\n\n'+links_section+'\n\n'+"•Useful external resources"+'\n\n'+external_resources_section+'\n\n'+"•Contact information for key team members"+'\n\n'+contact_info_section+'\n\n'
# print(references)

contents = intro + gettingstarted + req_lice_com_uf + Arch_overview + functionality + business_logic + technical_architecture + deployarchitecture + securityarchitecture + performance_architecture + technical_stack + source_code_review_section + codebase_structure + development_guidelines + testingframework + cicd + troubleshoot + improvements_section + references

# Function to get the table of contents section of the wiki
def toc():
    sme_flag = False
    if sme_flag:
        sme = smedata()
        return sme
    else:
        prompt=f"""Given below is a overall text containing various headings and description. Generate proper table of contents for only main headings.
        Output Format:
        ---content-----
        \nHere is the data:\n{contents}
        """
        genAI = genai(prompt)
        return genAI       
toc_section = toc()
# print(toc_section)

# final_doc = toc_section + contents

doc = Document()
# doc.add_paragraph(contents)
# # Save the document to a file
# doc.save('wiki2.docx')


# Add the content to the document
doc.add_paragraph('Contents', style='Heading 1').bold = True
doc.add_paragraph(toc_section)
doc.add_paragraph()

doc.add_paragraph('Introduction', style='Heading 2').bold = True
doc.add_paragraph()
doc.add_paragraph().add_run('Overview of the application').bold = True
doc.add_paragraph(overview_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Purpose of the application').bold = True
doc.add_paragraph(purpose_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Versions and release notes').bold = True
doc.add_paragraph(version_section)
doc.add_paragraph()

doc.add_paragraph('Getting Started', style='Heading 1').bold = True
doc.add_paragraph()
doc.add_paragraph().add_run('Setting up the development environment').bold = True
doc.add_paragraph(gettingstarted_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Installation guide').bold = True
doc.add_paragraph(installationguide_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Dependency & Configuration details').bold = True
doc.add_paragraph(dependency_section)
doc.add_paragraph()

doc.add_paragraph('Requirements', style='Heading 1').bold = True
doc.add_paragraph(requirements_section)
doc.add_paragraph()
doc.add_paragraph('License', style='Heading 1').bold = True
doc.add_paragraph(license_section)
doc.add_paragraph()
doc.add_paragraph('Common Setup', style='Heading 1').bold = True
doc.add_paragraph(commonsetup_section)
doc.add_paragraph()
doc.add_paragraph('User Flow', style='Heading 1').bold = True
doc.add_paragraph(userflow_section)
doc.add_paragraph()

doc.add_paragraph('Architecture Overview', style='Heading 1').bold = True
doc.add_paragraph()
doc.add_paragraph().add_run('Overview of System Architecture').bold = True
doc.add_paragraph(architecture_overview_section)
doc.add_paragraph()
doc.add_paragraph().add_run('High-level component Diagram').bold = True
doc.add_paragraph(highlevel_diagram_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Database schema overview').bold = True
doc.add_paragraph(database_overview_section)
doc.add_paragraph()

doc.add_paragraph('Functionality', style='Heading 1').bold = True
doc.add_paragraph()
doc.add_paragraph().add_run('Core features and functionalities').bold = True
doc.add_paragraph(functionality_section)
doc.add_paragraph()
doc.add_paragraph().add_run('User roles and permissions').bold = True
doc.add_paragraph(roles_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Use case scenarios with examples').bold = True
doc.add_paragraph(usecase_scenario_section)
doc.add_paragraph()

doc.add_paragraph('Business Logic', style='Heading 1').bold = True
doc.add_paragraph().add_run('Business rules and workflows').bold = True
doc.add_paragraph(business_rules_workflows_section)
doc.add_paragraph().add_run('External APIs or integrations').bold = True
doc.add_paragraph(external_api_section)
doc.add_paragraph().add_run('Data flow and processing').bold = True
doc.add_paragraph(dataflow_section)

doc.add_paragraph('Technical Architecture', style='Heading 1').bold = True
doc.add_paragraph()
doc.add_paragraph().add_run('Sequence Diagram').bold = True
doc.add_paragraph(sequence_diagram_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Class Diagram').bold = True
doc.add_paragraph(class_diagram_section)
doc.add_paragraph()
doc.add_paragraph().add_run('External Packages Or Imports').bold = True
doc.add_paragraph(external_packages_section)
doc.add_paragraph()

doc.add_paragraph('Deployment Architecture', style='Heading 1').bold = True
doc.add_paragraph()
doc.add_paragraph().add_run('Overview of deployment strategies (e.g., monolithic, microservices)').bold = True
doc.add_paragraph(deploy_architecture_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Scalability and redundancy considerations').bold = True
doc.add_paragraph(scalability_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Deployment diagrams').bold = True
doc.add_paragraph(deployment_diagram_section)
doc.add_paragraph()

doc.add_paragraph('Security Architecture', style='Heading 1').bold = True
doc.add_paragraph()
doc.add_paragraph().add_run('Authentication and authorization mechanisms').bold = True
doc.add_paragraph(security_architecture_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Encryption methods used').bold = True
doc.add_paragraph(encryption_methods_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Threat models and security protocols').bold = True
doc.add_paragraph(threat_models_section)
doc.add_paragraph()

doc.add_paragraph('Performance Architecture', style='Heading 1').bold = True
doc.add_paragraph()
doc.add_paragraph().add_run('Caching strategies employed').bold = True
doc.add_paragraph(caching_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Load balancing and optimization techniques').bold = True
doc.add_paragraph(load_balancing_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Performance testing results and benchmarks').bold = True
doc.add_paragraph(performance_testing_section)
doc.add_paragraph()

doc.add_paragraph('Technical Stack', style='Heading 1').bold = True
doc.add_paragraph()
doc.add_paragraph().add_run('Programming languages and frameworks used').bold = True
doc.add_paragraph(programming_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Third-party libraries and dependencies').bold = True
doc.add_paragraph(libraries_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Deployment strategies').bold = True
doc.add_paragraph(deployment_strategies_section)
doc.add_paragraph()

doc.add_paragraph('Codebase Structure', style='Heading 1').bold = True
doc.add_paragraph()
doc.add_paragraph().add_run('Directory structure').bold = True
doc.add_paragraph(directory_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Module breakdown and responsibilities').bold = True
doc.add_paragraph(module_breakdown_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Key files and their purposes').bold = True
doc.add_paragraph(key_files_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Detailed explanation of code').bold = True
doc.add_paragraph(detailed_explanation_code_section)
doc.add_paragraph()


doc.add_paragraph('Testing Framework', style='Heading 1').bold = True
doc.add_paragraph()
doc.add_paragraph().add_run('Description of testing frameworks').bold = True
doc.add_paragraph(testing_framework_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Examples of testing code and suites').bold = True
doc.add_paragraph(eaxmple_testing_framework_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Overview of testing methodologies used').bold = True
doc.add_paragraph(testing_methodologies_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Coverage reports and metrics').bold = True
doc.add_paragraph(coverage_reports_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Areas covered by different types of tests').bold = True
doc.add_paragraph(areas_covered_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Automation scripts for testing and deployment').bold = True
doc.add_paragraph(automation_scripts_section)
doc.add_paragraph()

doc.add_paragraph('Continuous Integration/Continuous Deployment (CI/CD)', style='Heading 1').bold = True
doc.add_paragraph()
doc.add_paragraph().add_run('Tools and Platforms').bold = True
doc.add_paragraph(tools_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Pipeline Configuration').bold = True
doc.add_paragraph(pipeline_configuration_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Monitoring and Optimization').bold = True
doc.add_paragraph(monitoring_section)
doc.add_paragraph()

doc.add_paragraph('Troubleshooting and FAQs', style='Heading 1').bold = True
doc.add_paragraph()
doc.add_paragraph().add_run('Common issues and solutions').bold = True
doc.add_paragraph(issues_solution_section)
doc.add_paragraph()
doc.add_paragraph().add_run('FAQs related to development and deployment').bold = True
doc.add_paragraph(faqs_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Troubleshooting steps for specific scenarios').bold = True
doc.add_paragraph(troubleshooting_steps_section)
doc.add_paragraph()

doc.add_paragraph('Improvements', style='Heading 1').bold = True
doc.add_paragraph(improvements_section)
doc.add_paragraph()

doc.add_paragraph('Resources and References', style='Heading 1').bold = True
doc.add_paragraph()
doc.add_paragraph().add_run('Links to relevant documentation').bold = True
doc.add_paragraph(links_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Useful external resources').bold = True
doc.add_paragraph(external_resources_section)
doc.add_paragraph()
doc.add_paragraph().add_run('Contact information for key team members').bold = True
doc.add_paragraph(contact_info_section)
doc.add_paragraph()

doc.save('final_wiki_document_3.docx')



#Function for the sme edit of the section and regenrating particular section of wiki
def smedata():
    messages = [] 
    section_name = "Overview of the Application"  # Section name should be parameterised
    text = f"""The BookStore web application is a platform for buying and selling books online. It includes features such as user authentication and 
    registration, shopping cart functionality, and payment processing. The application is built using Java servlets and uses a MySQL database to store 
    book and user information."""    # This should be parameterised. Based on the section name the previously generated content should come
    
    new_text = f"""The BookStore web application is a platform for buying and selling books online. It includes features such as user authentication and 
    registration, shopping cart functionality, and payment processing. The application is built using Java servlets and uses a MySQL database to store 
    book and user information. The application has two different logins admin and customers"""    # This should be parameterised. Based on the section name the previously generated content and sme added data should come
    
    new_prompt= sme_edit_prompt(section_name,new_text, text)   # calling the prompt section for the particular section name
    messages.append({'role':'user','content':new_prompt})
    response = openai.ChatCompletion.create(
        engine="genwizard-adm-brownfield",    # Give the model name
        messages = messages,
        temperature=0,  # Adjust the temperature for creativity
    )
    result=response.choices[0].message['content']
    return result

# Function for the prompts, for particular section name that will be called from the smedata function 
def sme_edit_prompt(section_name,new_text, text):
    if section_name == "Overview of the Application": 
        prompt = f"Generate the {section_name} from {new_text} without tampering its content and meaning from {text}"
    return prompt

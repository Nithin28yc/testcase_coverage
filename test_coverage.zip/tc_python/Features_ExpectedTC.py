import os
import openai
import pandas as pd
import csv 
import json
import time
# Set your OpenAI API key
openai.api_type = "azure"
openai.api_base = "https://devopsvalidation.openai.azure.com/"
openai.api_version = "2023-09-15-preview"
openai.api_key = "27940702532b4623b2c59a296bfe484b"

####--------- Function for Features derivation from the code in repo -------#######
def features_gen():
    code_snippet=''
    features=''
    
    java_files=[]
    path=r'C:\Users\nithin.y.c\OneDrive - Accenture\Documents\Code Coverage\ct_genai_testcoverage\onlinebookstore-master\src\main'  ##path need to be paramterised
    for root, dirs, files in os.walk(path):
        for file in files:
            if file.endswith(".java"):
                java_files.append(os.path.join(root, file))
    
    for file_name in java_files:
        if file_name.endswith(".java"):
            with open(file_name, 'r') as file:
                code_snippet=file.read()
            response = openai.Completion.create(
                    engine="devops",
                    prompt=f"Given the following code:\n\n{code_snippet}\n\nWrite the feature list in bullet points:\n",
                    max_tokens=2000,  # Adjust the number of tokens as needed
                    temperature=0,  # Adjust the temperature for creativity
            )
        features = response.choices[0].text
    response = openai.Completion.create(
        engine="devops",
        prompt=f"""Please generate a JSON list from {features} with only the following information:
                   Feature: 'Name of the feature'""",
        max_tokens=600,  # Adjust the number of tokens as needed
        temperature=0,  # Adjust the temperature for creativity
    )
    features_generated = response.choices[0].text
    print(features_generated)
    
    df = pd.read_json(features_generated)
    df.to_csv('test_coverage_new.csv', encoding='utf-8', index=False)
    print('Features successfully uploaded to csv')

###--------- Function for Expected Test Cases derivations from the features generated from the above---------- ####
def expected_tc_gen():
    features_list=[]
    with open('test_coverage_new.csv', newline='') as file:
        csv_reader = csv.DictReader(file)   
        for row in csv_reader:
            features_list.append(row['Feature'])
    tclist = ""
    all_features = features_list
    TestCases = ['Functional', 'Performance', 'Security']
    for eachtype in TestCases:
        for each_feature in all_features:
            response = openai.Completion.create(
                engine="devops",
                prompt=f""""Please generate a JSON structure with the following information:
                    Feature: '{each_feature}'
                    Expected Test Cases: Generate {eachtype} test cases, containing a list of test case descriptions.
                    Expected Test Cases Count: Count of test cases from the above.
                    Type: {eachtype}.
                """,
                max_tokens=800,  # Adjust the number of tokens as needed
                temperature=0.2,  # Adjust the temperature for creativity
            )
            tclist += response.choices[0].text + ", "
    tc_list_ = '[' + tclist
    if tc_list_.endswith(', '):
        tc_list_ = tc_list_[:-2]
    tc_list_ = tc_list_ + ']'
    print(tc_list_)
    df = pd.read_json(tc_list_)
    df.to_csv('test_coverage_new.csv', encoding='utf-8', index=False)
    print('Expected test cases successfully uploaded to csv')

### Calling Features generatin function ########
features_derivation = features_gen()

time.sleep(60)
### Calling Expected test cases generatin function ########
expected_tc_generation = expected_tc_gen()
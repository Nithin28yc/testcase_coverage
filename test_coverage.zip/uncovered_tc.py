import csv
import json
import os
import openai
import pandas as pd

# Set your OpenAI API key
openai.api_type = "###API_TYPE###"
openai.api_base = "###API_BASE###"
openai.api_version = "###API_VERSION###"
openai.api_key = "###API_KEY###"

# Specify the CSV file path
csv_file = 'test_coverage.csv'
test_cases = {}

with open(csv_file, newline='') as file:
    csv_reader = csv.DictReader(file)   
    for row in csv_reader:
        name = row['Feature']  # Use the header 'Name' as the key
        test_cases[name] = {
            'Expected Test Cases': row['Expected Test Cases'],
            'Actual Test Cases': row['Actual Test Cases'],
        }
# # print(test_cases)

response = openai.Completion.create(
    engine="devops",
    prompt=f"Compare expected test cases and actual test cases in plain language from {test_cases} and give the uncovered test cases count for each feature in proper json format.\n\n",
    # prompt=f"Compare expected test cases and actual test cases from {test_cases} and give the uncovered test cases from expected test cases and its count by comparing with actual test cases for each feature\n\n",
    # prompt=f"compare expected test cases and actual test cases from {test_cases} and for each test case in expected test cases, see if a mapping test case is present in actual test cases and if not found, mark as uncovered testcase\n\n",
    max_tokens=1000,  # Adjust the number of tokens as needed
    temperature=0.3,  # Adjust the temperature for creativity
)

actual_tc_count = response.choices[0].text
# print('actual count result',actual_tc_count)

with open('actual_tc_count.json', 'w') as file:
    file.write(actual_tc_count)

with open('actual_tc_count.json', encoding='utf-8') as inputfile:
    json_data = pd.read_json(inputfile)

# print(json_data)

df = pd.read_csv('test_coverage.csv')
for index, row in df.iterrows():
    if row["Feature"] in json_data:
        try:
            df.at[index, "Uncovered Test Cases Count"] = json_data[row["Feature"]]["Uncovered Test Cases Count"]
            df["Test Coverage in %"] = ((df["Expected Test cases count"] - df["Uncovered Test Cases Count"]) / df["Expected Test cases count"])*100
        except:
            df.at[index, "Uncovered Test Cases Count"] = json_data[row["Feature"]]["Uncovered Test Cases"]
            df["Test Coverage in %"] = ((df["Expected Test cases count"] - df["Uncovered Test Cases Count"]) / df["Expected Test cases count"])*100
df.to_csv('test_coverage.csv', index=False)

print('successfully completed')
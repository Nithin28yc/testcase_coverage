import csv
import os
import openai
import json

# Set your OpenAI API key
openai.api_type = "###API_TYPE###"
openai.api_base = "###API_BASE###"
openai.api_version = "###API_VERSION###"
openai.api_key = "###API_KEY###"

features_list=[]
with open('test_coverage_security.csv', newline='') as file:
    csv_reader = csv.DictReader(file)   
    for row in csv_reader:
        features_list.append(row['Feature'])

response = openai.Completion.create(
    engine="devops",
    prompt=f"Generate a json list of Security test cases for {features_list}.\n\n List should have : Feature, Expected Test Cases, Expected Test cases count and Type of the testcase as security in json format\n\n",
    # prompt=f"Given the following code:\n\n{feature_list}.Generate a table of of functional, performance, security test cases of 25 rows. Table should have columns Feature, Expected Test Cases, Expected Test cases count and Type of the testcase as functional, performance or security. Now, parse through given code \n\n{feature_list} and identify the test scripts in it for each feature in the table. Count and map the test scripts count to each feature in the table as next column",
    max_tokens=1500,  # Adjust the number of tokens as needed
    temperature=0.7,  # Adjust the temperature for creativity
)
tc_list = response.choices[0].text
print(tc_list)
with open('expected_sec_tc_from_feature.json', 'w') as file:
    file.write(tc_list)

import pandas as pd

with open('expected_sec_tc_from_feature.json', encoding='utf-8') as inputfile:
    df = pd.read_json(inputfile)

df.to_csv('test_coverage_security.csv', encoding='utf-8', index=False)

print('successfully executed')
import os
import openai
import pandas as pd
import csv 
import re
import json
# Set your OpenAI API key
openai.api_type = "###API_TYPE###"
openai.api_base = "###API_BASE###"
openai.api_version = "###API_VERSION###"
openai.api_key = "###API_KEY###"

#### Features derivation from the code in repo #######
def features_gen():
    code_snippet=''
    features=''
    
    java_files=[]
    path=r'C:\Users\nithin.y.c\OneDrive - Accenture\Documents\Code Coverage\ct_genai_testcoverage\onlinebookstore-master\src\main'  ##path need to be paramterised
    for root, dirs, files in os.walk(path):
        for file in files:
            if file.endswith(".java"):
                java_files.append(os.path.join(root, file))
    
    for file_name in java_files:
        if file_name.endswith(".java"):
            with open(file_name, 'r') as file:
                code_snippet=file.read()

            messages=[]
            prompt=f"Given the following code:\n\n{code_snippet}\n\nWrite the feature list in bullet points:\n"
            messages.append({'role':'user','content':prompt})
            response = openai.ChatCompletion.create(
                    engine="neww",
                    messages=messages,  # Adjust the number of tokens as needed
                    temperature=0,  # Adjust the temperature for creativity
            )
        features = response.choices[0].message['content']

    messages1=[]
    prompt1=f"""Please generate a JSON list from {features} with only the following information:
                   Feature: 'Name of the feature'"""
    messages1.append({'role':'user','content':prompt1})
    response1 = openai.ChatCompletion.create(
        engine="neww",
        messages=messages1,  # Adjust the number of tokens as needed
        temperature=0,  # Adjust the temperature for creativity
    )
    features_generated = response.choices[0].message['content']
    print(features_generated)
    
    df = pd.read_json(features_generated)
    df.to_csv('test_coverage.csv', encoding='utf-8', index=False)
    print('Features successfully uploaded to csv')

features_derivation = features_gen()
features_derivation
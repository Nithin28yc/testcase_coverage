import csv
import os
import re
import openai
import pandas as pd

# Set your OpenAI API key
openai.api_type = "###API_TYPE###"
openai.api_base = "###API_BASE###"
openai.api_version = "###API_VERSION###"
openai.api_key = "###API_KEY###"

# func_search_directory = 'onlinebookstore-master\/testscripts\Bookstore_Checks\src\/test\java\compliance\PageObjMethods'
# func_folder_path = os.listdir(func_search_directory)
#func_features_list = ['Login feature for customers and sellers', 'Registration of customers', 'Viewing available books']
func_features_list=[]
with open('test_coverage_excelMapping.csv', newline='') as file:
    csv_reader = csv.DictReader(file)   
    for row in csv_reader:
        if row['Type'] == 'Functional':
            func_features_list.append(row['Feature'])

#manual_features = ['Login feature', 'Login feature','Login feature','Registration','Registration','Registration','Registration','Viewing available books','Adding book']
# manual_features=[]
# with open('test_coverage_meaning.csv',newline='') as manualfile:
#     csv_reader = csv.DictReader(manualfile)
#     for row in csv_reader:
#         manual_features.append(row['Feature'])
messages=[]
messages1=[]
messages2=[]
file_path = 'test_coverage_meaning.csv'
df = pd.read_csv(file_path)
grouped_test_cases = df.groupby('Feature')['Test Case Description'].apply(lambda x: x.tolist() if x.any() else ['']).reset_index()
# print(grouped_test_cases)
# print('-----------------------------------------')
for expfeatures in func_features_list:
    # prompt=f"Get the meaning of {features} in plain language \n\n"
    # messages.append({'role':'user','content':prompt})
    # response = openai.ChatCompletion.create(
    #         engine="neww",
    #         messages = messages,
    #         #prompt=f"Get the meaning in plain language for {features}\n\n",
    #         #max_tokens=70,  # Adjust the number of tokens as needed
    #         temperature=0,  # Adjust the temperature for creativity
    #     )
    # res=response.choices[0].message['content']
    # print(res)
    for index, row in grouped_test_cases.iterrows():
        manfeature = row['Feature']
        test_cases = row['Test Case Description']

   

        # prompt1=f"""Get the meaning in plain language for {feature}\n"""
        # messages1.append({'role':'user','content':prompt1})
        # response1 = openai.ChatCompletion.create(
        #     engine="neww",
        #     messages = messages1,
        #     #prompt=f"""Get the meaning in plain language for {features1}\n""",
        #     #max_tokens=80,  # Adjust the number of tokens as needed
        #     temperature=0,  # Adjust the temperature for creativity
        # )
        # res1=response1.choices[0].message['content']
        # print(res1)
       

        prompt2=f"""Is both the meanings of '{expfeatures}' and '{manfeature}' is same in plain english language? Give the Output in Yes or No format only"""
        messages2.append({'role':'user','content':prompt2})
        response2 = openai.ChatCompletion.create(
            engine="neww",
            messages = messages2,
            #prompt=f"""Verify whether both the meanings of {res} and {res1} is same in plain language and describe the same thing of process. Dont compare with normal way. Give the Output in Yes or No""",
            #max_tokens=800,  # Adjust the number of tokens as needed
            temperature=0,  # Adjust the temperature for creativity
        )
        res2=response2.choices[0].message['content']
      #  print(res2)
        feature_test_cases = {}
        if "Yes" in res2:
            print(f"Feature: {expfeatures}")
            print(res2+ ": "+expfeatures+": "+manfeature)
            #for i, test_case in enumerate(test_cases):
            feature_test_cases[expfeatures]  = test_cases
            print(feature_test_cases )
                #print(f" Test Case {i}: {test_case if test_case else ''}")  
            df = pd.read_csv('test_coverage_excelMapping.csv')
            # Create a new column 'Actual TC' if not already present
            if 'Actual Test Cases' not in df.columns:
                df['Actual Test Cases'] = ''
                print("Created a Actual Test Cases for first time in csv ")
                df.to_csv('test_coverage_excelMapping.csv', index=False)
            # Loop through rows and organize test cases by feature
            for index, row in df.iterrows():
                mainfeature = row['Feature']  
                actual_tc = row['Actual Test Cases']
                # Append test case to the corresponding feature
                if mainfeature in feature_test_cases:
                    actual_tc = feature_test_cases[mainfeature] 
                # else:
                #     feature_test_cases[mainfeature] = [actual_tc]

            for keyfeature, test_cases in feature_test_cases.items():
                actual_tc = ', '.join(test_cases)
                df1 = pd.read_csv('test_coverage_excelMapping.csv')
                for index, row in df1.iterrows():
                #df.loc[df['Feature'] == mainfeature, 'Actual Test Cases'] = actual_tc
                    if row["Feature"] in keyfeature and row['Type'] == 'Functional':   
                        print(keyfeature)        
                        df1.at[index, "Actual Test Cases"] = actual_tc
            df1.to_csv('test_coverage_excelMapping.csv', index=False)
            print("updated to csv")
            print("------------------")
    print()
        #result1.append(response.choices[0].text)
#testcase_desc = []
# with open('test_coverage_meaning.csv',newline='') as manualfile1:
#     csv_reader = csv.DictReader(manualfile1)
#     for row in csv_reader:
#         testcase_desc.append(row['Test Case Description'])
# print(testcase_desc)
# result = []
# result1 = []
# message_text =[]






    #result.append(response.choices[0].text)
#     for features1 in manual_features:
#         prompt1=f"""Get the meaning in plain language for {features1}\n"""
#         messages1.append({'role':'user','content':prompt1})
#         response1 = openai.ChatCompletion.create(
#             engine="neww",
#             messages = messages1,
#             #prompt=f"""Get the meaning in plain language for {features1}\n""",
#             #max_tokens=80,  # Adjust the number of tokens as needed
#             temperature=0,  # Adjust the temperature for creativity
#         )
#         res1=response1.choices[0].message['content']
#        # print(res1)

#         prompt2=f"""Verify whether both the meanings of {res} and {res1} is same in plain language and describe the same thing of process. Compare only in technical meaning of what it does and Give the Output in Yes or No format only"""
#         messages2.append({'role':'user','content':prompt2})
#         response2 = openai.ChatCompletion.create(
#             engine="neww",
#             messages = messages2,
#             #prompt=f"""Verify whether both the meanings of {res} and {res1} is same in plain language and describe the same thing of process. Dont compare with normal way. Give the Output in Yes or No""",
#             #max_tokens=800,  # Adjust the number of tokens as needed
#             temperature=0,  # Adjust the temperature for creativity
#         )
#         res2=response2.choices[0].message['content']
#       #  print(res2)
#         if "Yes" in res2:
#             print(res2+ ": "+features+": "+features1)
        #result1.append(response.choices[0].text)


# for res in result:
#     for each_single_tc in testcase_desc:
#         response1 = openai.Completion.create(
#                 engine="devops",
#                # prompt=f"Get the meaning in plain language for {each_single_tc}\n\n",
#                 prompt="""Compare the meaning of {res} and {each_single_tc} in plain language and
#                 Get the output in Yes or No:\n\n""",
#                 max_tokens=700,  # Adjust the number of tokens as needed
#                 temperature=0.3,  # Adjust the temperature for creativity
#         )
#         #message_text.append(response1.choices[0].text)
#         yes=response1.choices[0].text
#         if yes in 'Yes':
#             print(yes+":\n"+res+":\n"+each_single_tc)
    # res = response1.choices[0].text
    # if res in 'Yes':
    #     print(features+":"+each_single_tc)
#        result.append(response1.choices[0].text)
#Function to search for files
# def func_search_files(directory, keyword):
#     result = []
#     # for file in func_folder_path:
#     #     if file.endswith('.java'):
#     #         file_wo_ext = file.replace('.java','')
#      #       if re.match(keyword, file_wo_ext, re.IGNORECASE) or keyword in file_wo_ext:
#                 # result.append(file_wo_ext)
#                 # with open(func_search_directory+'\\'+file, 'r') as file:
#                 #     code_snippet=file.read()
#     response = openai.Completion.create(
#         engine="devops",
#         prompt=f"Give the list of covered functional test cases in plain language without test steps from the {code_snippet}\n\n",
#         max_tokens=700,  # Adjust the number of tokens as needed
#         temperature=0.7,  # Adjust the temperature for creativity
#     )
#     result.append(response.choices[0].text)
#                 # print(result)
#     return result

# func_file_results = {}
# for func_feature in func_features_list:
#     # print(re.sub(r'\s+', '', keyword))
#     matches = func_search_files(func_search_directory, re.sub(r'\s+', '', func_feature))
#     if matches:
#         func_file_results[func_feature] = matches
# print("Functional testcases:")
# print(func_file_results)




# df = pd.read_csv('test_coverage_all.csv')
# for index, row in df.iterrows():
#     if row["Feature"] in func_file_results and row['Type'] == 'Functional':
#         df.at[index, "Actual Test Cases"] = str(func_file_results[row["Feature"]])

# df.to_csv('test_coverage_all.csv', index=False)

print('successfully completed')
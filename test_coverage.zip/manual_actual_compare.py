import csv
import os
import re
import openai
import pandas as pd

# Set your OpenAI API key
openai.api_type = "###API_TYPE###"
openai.api_base = "###API_BASE###"
openai.api_version = "###API_VERSION###"
openai.api_key = "###API_KEY###"
####------Path for automation test scripts---------#######
search_directory = r'onlinebookstore-master\meaning'
folder_path = os.listdir(search_directory)

#####----Path for manual test cases------#####
file_path = 'test_coverage_meaning.csv'
df = pd.read_csv(file_path)
grouped_test_cases = df.groupby('Feature')['Test Case Description'].apply(lambda x: x.tolist() if x.any() else ['']).reset_index()

####----Taking features from main excel------####
func_features_list=[]
with open('test_coverage_excelMapping.csv', newline='') as file:
    csv_reader = csv.DictReader(file)   
    for row in csv_reader:
        if row['Type'] == 'Functional':
            func_features_list.append(row['Feature'])

#####----Generating testcases from automation scriots----#####
def automation_tc():
    result=[]
    result=""
    for expfeatures in func_features_list:
        for file in folder_path:
            if file.endswith('.java'):
                file_wo_ext = file.replace('.java','')
            
                messages1 = []
                prompt1=f"""Is both the meanings of '{expfeatures}' and '{file_wo_ext}' is same in plain english language? Give the Output in Yes or No format only"""
                messages1.append({'role':'user','content':prompt1})
                response1 = openai.ChatCompletion.create(
                    engine="neww",
                    messages = messages1,
                    temperature=0,  # Adjust the temperature for creativity
                )
                res1=response1.choices[0].message['content']

                if "Yes" in res1:
                    with open(search_directory+'\\'+file, 'r') as file:
                        code_snippet=file.read()
                    messages2=[]
                    prompt2=f"Give the list of covered test cases without test steps from the {code_snippet}\n\n"
                    messages2.append({'role':'user','content':prompt2})
                    tc_response = openai.ChatCompletion.create(
                        engine="neww",
                        messages = messages2,
                        temperature=0,
                    )
                    tc_resp = tc_response.choices[0].message['content']
                    result = result + "\n"+ expfeatures + ":" + tc_resp
                    #result.append(tc_response.choices[0].text)
    print(result)


#actual = automation_tc()

####-----Getting testcases from manual written testcases for features----#####
def manual_tc():
    messages=[]
    for expfeatures in func_features_list:
        for index, row in grouped_test_cases.iterrows():
            manfeature = row['Feature']
            test_cases = row['Test Case Description']

            prompt=f"""Is both the meanings of '{expfeatures}' and '{manfeature}' is same in plain english language? Give the Output in Yes or No format only"""
            messages.append({'role':'user','content':prompt})
            response = openai.ChatCompletion.create(
                engine="neww",
                messages = messages,
                temperature=0,  # Adjust the temperature for creativity
            )
            res=response.choices[0].message['content']
            feature_test_cases = {}
            if "Yes" in res:
                print(f"Feature: {expfeatures}")
                print(res+ ": "+expfeatures+": "+manfeature)
                #for i, test_case in enumerate(test_cases):
                feature_test_cases[expfeatures]  = test_cases
                print(feature_test_cases )

manual = manual_tc()

package compliance.PageObjMethods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

public class AddingBooksToCart {
    private WebDriver driver;

    public AddingBooksToCart(WebDriver driver) {
        this.driver = driver;
    }

    @FindBy(xpath = "//a[@id='addbook']")
    public WebElement addbooks;

    @FindBy(xpath = "//a[@id='bookName']")
    public WebElement bookname;

    @FindBy(xpath = "//a[@id='bookAuthor']")
    public WebElement bookauthor;

    @FindBy(xpath = "//input[@name='price']")
    public WebElement price;

    public void addingbooktocart() {
        addbooks.click();
        System.out.println("Able to add a book to the cart");
    }

    public void addingmultiplebooktocart() {
        List<String> booksToAdd = new ArrayList<>();
        booksToAdd.add("Book 1");
        booksToAdd.add("Book 2");
        booksToAdd.add("Book 3");

        for (String book : booksToAdd) {
            WebElement bookLink = driver.findElement(By.linkText(book));
            bookLink.click();
            WebDriverWait wait = new WebDriverWait(driver, 10);
            WebElement addToCartButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("add-to-cart-button")));
            addToCartButton.click();

        }

        System.out.println("Able to add multiple books to the cart");
    }

    public void verifybooksincart() {
        WebElement cartElement = driver.findElement(By.xpath("//a[@id='cart']"));

        String cartText = cartElement.getText();
        Assert.assertFalse(cartText.equals("0"));
        System.out.println("Able to view books added to the cart");
    }
}
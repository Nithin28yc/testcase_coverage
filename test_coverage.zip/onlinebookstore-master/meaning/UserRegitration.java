package compliance.PageObjMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class RegistrationOfCustomers {
    private WebDriver driver;

    public RegistrationOfCustomers(WebDriver driver) {
        this.driver = driver;
    }

    public void successfulRegistration() {
        WebElement firstNameField = driver.findElement(By.id("firstName"));
        WebElement lastNameField = driver.findElement(By.id("lastName"));
        WebElement emailField = driver.findElement(By.id("email"));
        WebElement passwordField = driver.findElement(By.id("password"));
        WebElement registerButton = driver.findElement(By.id("registerButton"));

        // Fill in registration details
        firstNameField.sendKeys("John");
        lastNameField.sendKeys("Doe");
        emailField.sendKeys("johndoe@example.com");
        passwordField.sendKeys("password123");
        registerButton.click();
        WebElement successMessage = driver.findElement(By.id("successMessage"));
        Assert.assertTrue(successMessage.isDisplayed());
        System.out.println("Successful registration done with all the parameters entered");
    }

    public void unsuccessfulRegistration() {
        WebElement firstNameField = driver.findElement(By.id("firstName"));
        WebElement lastNameField = driver.findElement(By.id("lastName"));
        WebElement emailField = driver.findElement(By.id("email"));
        WebElement passwordField = driver.findElement(By.id("password"));
        WebElement registerButton = driver.findElement(By.id("registerButton"));
        firstNameField.sendKeys("John");
        lastNameField.sendKeys("Doe"); 
        emailField.sendKeys("invalid_email"); 
        passwordField.sendKeys("short");

        registerButton.click();

        WebElement errorMessage = driver.findElement(By.id("errorMessage"));

        Assert.assertTrue(errorMessage.isDisplayed());
        System.out.println("Unsuccessful registration done with few parameters entered");
    }

    public void teardown() {
        // Close the browser after the test
        driver.quit();
    }
}
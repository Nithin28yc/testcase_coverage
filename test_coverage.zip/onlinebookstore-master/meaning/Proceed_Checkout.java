package compliance.PageObjMethods;

public class PaymentProcessing {
	public void paymentProcessing() {
		System.setProperty("webdriver.chrome.driver", "path_to_chromedriver.exe");

        WebDriver driver = new ChromeDriver();

        driver.get("http://your-online-bookstore.com");

        WebElement checkoutButton = driver.findElement(By.id("checkoutButton"));
        checkoutButton.click();

        WebElement cardNumberInput = driver.findElement(By.id("cardNumber"));
        cardNumberInput.sendKeys("1234 5678 9012 3456");

        WebElement payButton = driver.findElement(By.id("payButton"));
        payButton.click();

        WebElement confirmationMessage = driver.findElement(By.id("confirmationMessage"));
        String message = confirmationMessage.getText();
        if (message.contains("Payment successful")) {
            System.out.println("Payment was successful.");
        } else {
            System.out.println("Payment failed.");
        }

        driver.quit();

		
	}
}

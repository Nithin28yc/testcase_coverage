package SIT_PERF
import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class AddToCartSimulation extends Simulation {
  val httpConf = http.baseUrl("http://ab84249b9624c455b86a74a68c285be3-159334186.us-east-1.elb.amazonaws.com:8080/onlinebookstore/")

  val books = List("book1", "book2", "book3")  // List of books to add to the cart

  val addToCartScenario = scenario("Add Books to Cart")
    .exec(foreach(books, "book") {
      exec(session => session.set("bookId", "${book}"))
        .exec(
          http("Add to Cart")
            .post("/cart/add")  // Update with your actual add to cart endpoint
            .formParam("bookId", "${bookId}")
            .check(status.is(200))
        )
    })

  setUp(
    addToCartScenario.inject(atOnceUsers(20))
  ).protocols(httpConf)
}
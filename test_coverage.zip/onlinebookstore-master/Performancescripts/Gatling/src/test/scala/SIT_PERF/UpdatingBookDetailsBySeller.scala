package SIT_PERF
import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class UpdateBookDetailsSimulation extends Simulation {
  val httpConf = http.baseUrl("http://ab84249b9624c455b86a74a68c285be3-159334186.us-east-1.elb.amazonaws.com:8080/onlinebookstore/")

  val sellerCredentials = csv("seller_credentials.csv").random // CSV file with seller credentials
  val booksToUpdate = csv("books_to_update.csv").random // CSV file with book details to update

  val updateBookScenario = scenario("Update Book Details")
    .feed(sellerCredentials)
    .feed(booksToUpdate)
    .exec(
      http("Seller Login")
        .post("/seller/login") // Update with your actual seller login endpoint
        .formParam("username", "${username}")
        .formParam("password", "${password}")
        .check(status.is(200))
    )
    .exec(
      http("Update Book Details")
        .post("/seller/update/book") // Update with your actual book update endpoint
        .formParam("sellerId", "${sellerId}")
        .formParam("bookId", "${bookId}")
        .formParam("newTitle", "${newTitle}")
        .formParam("newPrice", "${newPrice}")
        .check(status.is(200))
    )

  setUp(
    updateBookScenario.inject(atOnceUsers(10))
  ).protocols(httpConf)
}

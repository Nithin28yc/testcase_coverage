package SIT_PERF
import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class RegistrationSimulation extends Simulation {
  val httpConf = http.baseUrl("http://ab84249b9624c455b86a74a68c285be3-159334186.us-east-1.elb.amazonaws.com:8080/onlinebookstore/")

  val users = csv("new_customer_credentials.csv").random  // CSV file with user registration data

  val registrationScenario = scenario("Customer Registration")
    .feed(users)
    .exec(
      http("Register Customer")
        .post("/customer/register")  // Update with your actual registration endpoint
        .formParam("username", "${username}")
        .formParam("password", "${password}")
        .formParam("email", "${email}")
        .check(status.is(200))
    )

  setUp(
    registrationScenario.inject(atOnceUsers(16))
  ).protocols(httpConf)
}


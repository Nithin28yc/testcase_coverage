package SIT_PERF
import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class PaymentSimulation extends Simulation {
  val httpConf = http.baseUrl("http://ab84249b9624c455b86a74a68c285be3-159334186.us-east-1.elb.amazonaws.com:8080/onlinebookstore/")

  val books = List("book1", "book2", "book3")  // List of books to purchase
  val users = csv("user_credentials.csv").random  // CSV file with user credentials

  val paymentScenario = scenario("Payment Processing")
    .feed(users)
    .foreach(books, "book") {
      exec(session => session.set("bookId", "${book}"))
        .exec(
          http("Add to Cart")
            .post("/cart/add")  // Update with your actual add to cart endpoint
            .formParam("bookId", "${bookId}")
            .check(status.is(200))
        )
    }
    .pause(5)  // Pause for 5 seconds before proceeding to payment
    .exec(
      http("Checkout")
        .post("/checkout")  // Update with your actual checkout endpoint
        .formParam("userId", "${userId}")
        .check(status.is(200))
    )
    .pause(2)  // Pause for 2 seconds before proceeding to payment
    .exec(
      http("Make Payment")
        .post("/payment/process")  // Update with your actual payment processing endpoint
        .formParam("userId", "${userId}")
        .check(status.is(200))
    )

  setUp(
    paymentScenario.inject(atOnceUsers(10))
  ).protocols(httpConf)
}


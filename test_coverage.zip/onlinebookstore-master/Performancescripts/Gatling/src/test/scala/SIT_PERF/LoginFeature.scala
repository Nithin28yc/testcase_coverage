package SIT_PERF
import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class LoginSimulation  extends Simulation {

	val httpProtocol = http
		.baseUrl("http://ab84249b9624c455b86a74a68c285be3-159334186.us-east-1.elb.amazonaws.com:8080/onlinebookstore/")

	val customerFeeder = csv("customer_credentials.csv").circular
	val sellerFeeder = csv("seller_credentials.csv").circular
	
	val customerScenario = scenario("Customer Login")
    .feed(customerFeeder)
    .exec(
      http("Customer Login")
        .post("/customer/login")  // Update with your actual login endpoint
        .formParam("username", "${username}")
        .formParam("password", "${password}")
        .check(status.is(200))
    )

    val sellerScenario = scenario("Seller Login")
    .feed(sellerFeeder)
    .exec(
      http("Seller Login")
        .post("/seller/login")  // Update with your actual login endpoint
        .formParam("username", "${username}")
        .formParam("password", "${password}")
        .check(status.is(200))
    )

  setUp(
    customerScenario.inject(rampUsers(10) during (10 seconds)),
    sellerScenario.inject(rampUsers(10) during (10 seconds))
  ).protocols(httpConf)
}
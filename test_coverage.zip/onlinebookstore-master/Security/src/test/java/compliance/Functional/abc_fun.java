package compliance.Functional;

import Generic.TestBase.BrowserConfig;
import Generic.TestBase.ExcelOp;
import Generic.TestBase.testBase;
import compliance.PageObjMethods.Login;
import compliance.PageObjMethods.abc;
import compliance.PageObjMethods.myNav_AWSCloud_Creation;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;



public class abc_fun extends testBase{

	
	public WebDriver driver = null;
	public static String parent;
	public String parentHandle = null;
	public static boolean classname;

	@BeforeClass
	public void initSetUp() throws IOException, InterruptedException {

		BrowserConfig.setDriver(browserType, appURL);
		driver=BrowserConfig.getDriver();

		try {
			if (driver == null)
				System.out.println("---Driver not found---");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		classname = true;

	}

	@Test( priority = 0, enabled = true)
	public void platformValidLogin() throws InterruptedException, IOException {
		Login login = PageFactory.initElements(driver, Login.class);
		login.devOpsPlatformLogin(testBase.getUsername(), testBase.getPassword());

	}

	@Test( priority = 1, enabled = true)
	public void ManagePlatform() throws InterruptedException, IOException {
		abc mps = PageFactory.initElements(driver, abc.class);
		mps.validate_useraccessmanagement();
	}

//	@Test( priority = 2, enabled = true)
//	public void groupname() throws InterruptedException, IOException {
//		abc na = PageFactory.initElements(driver, abc.class);
		
//		int nameCount = ExcelOp.getRowCount("Group");
//		System.out.println(nameCount);
//		for (int row=1; row<=nameCount; row++) {
//			testBase.groupnamevalidation = ExcelOp.ReadExcelData("Group", row, "name");			
//			if (testBase.groupnamevalidation.contains("NA"))
//				break;
//			else
//				na.verifyGroupName(testBase.groupnamevalidation);
//		}
//	}
//	@Test( priority = 3, enabled = true)
//	public void description() throws InterruptedException, IOException {
//		abc des = PageFactory.initElements(driver, abc.class);
//		
//		int groupdescriptionCount = ExcelOp.getRowCount("Group");
//		for (int row=1; row<=groupdescriptionCount; row++) {
//			testBase.groupdescriptionvalidation = ExcelOp.ReadExcelData("Group", row, "description");			
//			if (testBase.groupdescriptionvalidation.contains("NA"))
//				break;
//			else
//				des.verifyGroupDescription(testBase.groupdescriptionvalidation);
//		}
//	}

	@AfterClass
	public void endDriver() {
		//driver.quit();
	}
}

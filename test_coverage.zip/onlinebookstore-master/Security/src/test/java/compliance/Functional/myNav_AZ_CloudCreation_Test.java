package compliance.Functional;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Generic.TestBase.BrowserConfig;
import Generic.TestBase.ExcelOp;
import Generic.TestBase.testBase;
import compliance.PageObjMethods.Login;
import compliance.PageObjMethods.myNav_AZ_CloudCreation;

public class myNav_AZ_CloudCreation_Test extends testBase {

	public WebDriver driver = null;
	String parent;
	public String parentHandle = null;
	public static boolean classname;

	@BeforeClass
	public void initSetUp() throws IOException, InterruptedException {

		BrowserConfig.setDriver(browserType, appURL);
		driver=BrowserConfig.getDriver();
		ExcelOp.loadExcel("MyNav");

		try {
			if (driver == null)
				System.out.println("---Driver not found---");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		classname = true;

	}

	@Test( priority = 0, enabled = true)
	public void platformValidLogin() throws InterruptedException, IOException {
		Login login = PageFactory.initElements(driver, Login.class);
		login.devOpsPlatformLogin(testBase.getUsername(), testBase.getPassword());

	}

	@Test( priority = 1, enabled = true)
	public void ManagePlatform() throws InterruptedException, IOException {
		myNav_AZ_CloudCreation mps = PageFactory.initElements(driver, myNav_AZ_CloudCreation.class);
		mps.cloudaccountManager();
	}

	@Test( priority = 2, enabled = true)
	public void name() throws InterruptedException, IOException {
		myNav_AZ_CloudCreation mps = PageFactory.initElements(driver, myNav_AZ_CloudCreation.class);
		int nameCount = ExcelOp.getRowCount("Azure");
		System.out.println(nameCount);
		for (int row=1; row<=nameCount; row++) {
			testBase.namevalidation = ExcelOp.ReadExcelData("Azure", row, "name");
			if (testBase.namevalidation.contains("NA"))
				break;
			else
				mps.verifyName(testBase.namevalidation);
		}
	}

	@Test( priority = 3, enabled = true)
	public void description() throws InterruptedException, IOException {
		myNav_AZ_CloudCreation mps = PageFactory.initElements(driver, myNav_AZ_CloudCreation.class);
		int desCount = ExcelOp.getRowCount("Azure");
		for (int row=1; row<=desCount; row++) {
			testBase.descriptionvalidation = ExcelOp.ReadExcelData("Azure", row, "description");
			if (testBase.descriptionvalidation.contains("NA")) 
				break;
			else
				mps.verifyDescription(testBase.descriptionvalidation);
		}
	}

	@Test( priority = 4, enabled = true)
	public void environment() throws InterruptedException, IOException {
		myNav_AZ_CloudCreation mps = PageFactory.initElements(driver, myNav_AZ_CloudCreation.class);
		int envCount = ExcelOp.getRowCount("Azure");
		for (int row=1; row<=envCount; row++) {
			testBase.envalidation = ExcelOp.ReadExcelData("Azure", row, "environment");
			if (testBase.envalidation.contains("NA"))
				break;
			else
				mps.verifyEnvironment(testBase.envalidation);
		}
	}

	@Test( priority = 5, enabled = true)
	public void region() throws InterruptedException, IOException {
		myNav_AZ_CloudCreation mps = PageFactory.initElements(driver, myNav_AZ_CloudCreation.class);
		int regionCount = ExcelOp.getRowCount("Azure");
		for (int row=1; row<=regionCount; row++) {
			testBase.regionvalidation = ExcelOp.ReadExcelData("Azure", row, "region");
			if (testBase.regionvalidation.contains("NA"))
				break;
			else
				mps.verifyRegion(testBase.regionvalidation);
		}
	}

	@Test( priority = 6, enabled = true)
	public void sub_id() throws InterruptedException, IOException {
		myNav_AZ_CloudCreation mps = PageFactory.initElements(driver, myNav_AZ_CloudCreation.class);
		int sidCount = ExcelOp.getRowCount("Azure");
		for (int row=1; row<=sidCount; row++) {
			testBase.sidvalidation = ExcelOp.ReadExcelData("Azure", row, "sid");
			if (testBase.sidvalidation.contains("NA"))
				break;
			else
				mps.verifySid(testBase.sidvalidation);
		}
	}

	@Test( priority = 7, enabled = true)
	public void tenanat_id() throws InterruptedException, IOException {
		myNav_AZ_CloudCreation mps = PageFactory.initElements(driver, myNav_AZ_CloudCreation.class);
		int tidCount = ExcelOp.getRowCount("Azure");
		for (int row=1; row<=tidCount; row++) {
			testBase.tidvalidation = ExcelOp.ReadExcelData("Azure", row, "tid");
			if (testBase.tidvalidation.contains("NA"))
				break;
			else
				mps.verifyTid(testBase.tidvalidation);
		}
	}

	@Test( priority = 8, enabled = true)
	public void client_id() throws InterruptedException, IOException {
		myNav_AZ_CloudCreation mps = PageFactory.initElements(driver, myNav_AZ_CloudCreation.class);
		int cidCount = ExcelOp.getRowCount("Azure");
		for (int row=1; row<=cidCount; row++) {
			testBase.cidvalidation = ExcelOp.ReadExcelData("Azure", row, "cid");
			if (testBase.cidvalidation.contains("NA"))
				break;
			else
				mps.verifyCid(testBase.cidvalidation);
		}
	}

	@Test( priority = 9, enabled = true)
	public void client_sec() throws InterruptedException, IOException {
		myNav_AZ_CloudCreation mps = PageFactory.initElements(driver, myNav_AZ_CloudCreation.class);
		int csCount = ExcelOp.getRowCount("Azure");
		for (int row=1; row<=csCount; row++) {
			testBase.csvalidation = ExcelOp.ReadExcelData("Azure", row, "cs");
			if (testBase.csvalidation.contains("NA"))
				break;
			else
				mps.verifyCs(testBase.csvalidation);
		}
	}
	@AfterClass
	public void endDriver() {
		//driver.quit();
	}


}



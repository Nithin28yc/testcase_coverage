package compliance.Functional;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Generic.TestBase.BrowserConfig;
import Generic.TestBase.ExcelOp;
import Generic.TestBase.testBase;
import compliance.PageObjMethods.Login;
import compliance.PageObjMethods.OrcheStratorAPIJenkinsEndpointCreation;
import compliance.PageObjMethods.OrchestratorAPIMorEndpointCreation;

public class OrchestratorAPIMorpheusEndpointCreation_Test extends testBase {

	public WebDriver driver = null;
	String parent;
	public String parentHandle = null;
	public static boolean classname;

	@BeforeClass
	public void initSetUp() throws IOException, InterruptedException {

		BrowserConfig.setDriver(browserType, appURL);
		driver=BrowserConfig.getDriver();
		ExcelOp.loadExcel("MyNav");

		try {
			if (driver == null)
				System.out.println("---Driver not found---");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		classname = true;

	}

	@Test( priority = 0, enabled = true)
	public void platformValidLogin() throws InterruptedException, IOException {
		Login login = PageFactory.initElements(driver, Login.class);
		login.devOpsPlatformLogin(testBase.getUsername(), testBase.getPassword());

	}

	@Test( priority = 1, enabled = true)
	public void Orchestrator_04() throws InterruptedException, IOException {
		OrchestratorAPIMorEndpointCreation mpo = PageFactory.initElements(driver, OrchestratorAPIMorEndpointCreation.class);
	   mpo.Orchestrator_Morpheous();
	}
	@Test( priority = 2, enabled = true)
	public void name() throws InterruptedException, IOException {
		OrchestratorAPIMorEndpointCreation na = PageFactory.initElements(driver, OrchestratorAPIMorEndpointCreation.class);

		int nameCount = ExcelOp.getRowCount("morpheus");
		for (int row=1; row<=nameCount; row++) {
			testBase.namevalidation = ExcelOp.ReadExcelData("morpheus", row, "name");
			if (testBase.namevalidation.contains("NA"))
				break;
			else
				na.verifyname(testBase.namevalidation);
		}
	}
	
	@Test( priority = 3, enabled = true)
	public void token() throws InterruptedException, IOException {
		OrchestratorAPIMorEndpointCreation na = PageFactory.initElements(driver, OrchestratorAPIMorEndpointCreation.class);

		int nameCount = ExcelOp.getRowCount("morpheus");
		for (int row=1; row<=nameCount; row++) {
			testBase.descriptionvalidation = ExcelOp.ReadExcelData("morpheus", row, "token");
			if (testBase.descriptionvalidation.contains("NA"))
				break;
			else
				na.verifytoken(testBase.descriptionvalidation);
		}
	}
	@Test( priority = 4, enabled = true)
	public void integrationid() throws InterruptedException, IOException {
		OrchestratorAPIMorEndpointCreation na = PageFactory.initElements(driver, OrchestratorAPIMorEndpointCreation.class);

		int nameCount = ExcelOp.getRowCount("morpheus");
		for (int row=1; row<=nameCount; row++) {
			testBase.accountIdvalidation = ExcelOp.ReadExcelData("morpheus", row, "integration_id");
			if (testBase.accountIdvalidation.contains("NA"))
				break;
			else
				na.verifyInteid(testBase.accountIdvalidation);
		}
	}
	@Test( priority = 5, enabled = true)
	public void apiendpoint() throws InterruptedException, IOException {
		OrchestratorAPIMorEndpointCreation na = PageFactory.initElements(driver, OrchestratorAPIMorEndpointCreation.class);

		int nameCount = ExcelOp.getRowCount("morpheus");
		for (int row=1; row<=nameCount; row++) {
			testBase.envalidation = ExcelOp.ReadExcelData("morpheus", row, "apiendpoint");
			if (testBase.envalidation.contains("NA"))
				break;
			else
				na.verifyapi(testBase.envalidation);
		}
	}
	@AfterClass
	public void endDriver() {
		//driver.quit();
	}

}

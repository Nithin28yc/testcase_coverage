package compliance.Functional;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Generic.TestBase.BrowserConfig;
import Generic.TestBase.ExcelOp;
import Generic.TestBase.testBase;
import compliance.PageObjMethods.Login;
import compliance.PageObjMethods.OrcheStratorAPIAzureEndpointCreation;
import compliance.PageObjMethods.OrcheStratorAPIGitEndpointCreation;

public class OrchestratorAPIAzureEndpointCreation_Test extends testBase{
	
	public WebDriver driver = null;
	String parent;
	public String parentHandle = null;
	public static boolean classname;

	@BeforeClass
	public void initSetUp() throws IOException, InterruptedException {

		BrowserConfig.setDriver(browserType, appURL);
		driver=BrowserConfig.getDriver();
		ExcelOp.loadExcel("MyNav");

		try {
			if (driver == null)
				System.out.println("---Driver not found---");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		classname = true;

	}

	@Test( priority = 0, enabled = true)
	public void platformValidLogin() throws InterruptedException, IOException {
		Login login = PageFactory.initElements(driver, Login.class);
		login.devOpsPlatformLogin(testBase.getUsername(), testBase.getPassword());

	}

	@Test( priority = 1, enabled = true)
	public void Orchestrator_02() throws InterruptedException, IOException {
		OrcheStratorAPIAzureEndpointCreation mpo = PageFactory.initElements(driver, OrcheStratorAPIAzureEndpointCreation.class);
	   mpo.Orchestrator_Azure();
	}
	
	@Test( priority = 2, enabled = true)
	public void name() throws InterruptedException, IOException {
		OrcheStratorAPIAzureEndpointCreation na = PageFactory.initElements(driver, OrcheStratorAPIAzureEndpointCreation.class);

		int nameCount = ExcelOp.getRowCount("azure_devops");
		for (int row=1; row<=nameCount; row++) {
			testBase.namevalidation = ExcelOp.ReadExcelData("azure_devops", row, "name");
			if (testBase.namevalidation.contains("NA"))
				break;
			else
				na.verifyname(testBase.namevalidation);
		}
	}
	@Test( priority = 3, enabled = true)
	public void username() throws InterruptedException, IOException {
		OrcheStratorAPIAzureEndpointCreation na = PageFactory.initElements(driver, OrcheStratorAPIAzureEndpointCreation.class);

		int nameCount = ExcelOp.getRowCount("azure_devops");
		for (int row=1; row<=nameCount; row++) {
			testBase.descriptionvalidation = ExcelOp.ReadExcelData("azure_devops", row, "username");
			if (testBase.descriptionvalidation.contains("NA"))
				break;
			else
				na.verifyusername(testBase.descriptionvalidation);
		}
	}
	@Test( priority = 4, enabled = true)
	public void password() throws InterruptedException, IOException {
		OrcheStratorAPIAzureEndpointCreation na = PageFactory.initElements(driver, OrcheStratorAPIAzureEndpointCreation.class);

		int nameCount = ExcelOp.getRowCount("azure_devops");
		for (int row=1; row<=nameCount; row++) {
			testBase.passwordvalidation = ExcelOp.ReadExcelData("azure_devops", row, "password");
			if (testBase.passwordvalidation.contains("NA"))
				break;
			else
				na.verifypassword(testBase.passwordvalidation);
		}
	}
	
	@Test( priority = 5, enabled = true)
	public void definitionid() throws InterruptedException, IOException {
		OrcheStratorAPIAzureEndpointCreation na = PageFactory.initElements(driver, OrcheStratorAPIAzureEndpointCreation.class);

		int nameCount = ExcelOp.getRowCount("azure_devops");
		for (int row=1; row<=nameCount; row++) {
			testBase.sidvalidation = ExcelOp.ReadExcelData("azure_devops", row, "definition_id");
			if (testBase.sidvalidation.contains("NA"))
				break;
			else
				na.verifydid(testBase.sidvalidation);
		}
	}
	@Test( priority = 6, enabled = true)
	public void apiendpoint() throws InterruptedException, IOException {
		OrcheStratorAPIAzureEndpointCreation na = PageFactory.initElements(driver, OrcheStratorAPIAzureEndpointCreation.class);

		int nameCount = ExcelOp.getRowCount("azure_devops");
		//	System.out.println(nameCount);
		for (int row=1; row<=nameCount; row++) {
			testBase.envalidation = ExcelOp.ReadExcelData("azure_devops", row, "apiendpoint");
			if (testBase.envalidation.contains("NA"))
				break;
			else
				na.verifyapi(testBase.envalidation);
		}
	}
	
	@AfterClass
	public void endDriver() {
		//driver.quit();
	}


}

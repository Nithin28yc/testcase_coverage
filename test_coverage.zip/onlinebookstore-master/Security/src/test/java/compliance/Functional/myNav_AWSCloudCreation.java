package compliance.Functional;

import Generic.TestBase.BrowserConfig;
import Generic.TestBase.ExcelOp;
import Generic.TestBase.testBase;
import compliance.PageObjMethods.Login;
import compliance.PageObjMethods.myNav_AWSCloud_Creation;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;



public class myNav_AWSCloudCreation extends testBase{
	public WebDriver driver = null;
	String parent;
	public String parentHandle = null;
	public static boolean classname;

	@BeforeClass
	public void initSetUp() throws IOException, InterruptedException {

		BrowserConfig.setDriver(browserType, appURL);
		driver=BrowserConfig.getDriver();
		ExcelOp.loadExcel("MyNav");

		try {
			if (driver == null)
				System.out.println("---Driver not found---");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		classname = true;

	}

	@Test( priority = 0, enabled = true)
	public void platformValidLogin() throws InterruptedException, IOException {
		Login login = PageFactory.initElements(driver, Login.class);
		login.devOpsPlatformLogin(testBase.getUsername(), testBase.getPassword());

	}
	
	@Test( priority = 1, enabled = true)
	public void ManagePlatform() throws InterruptedException, IOException {
		myNav_AWSCloud_Creation mps = PageFactory.initElements(driver, myNav_AWSCloud_Creation.class);
		mps.validate_cloudaccountManager();
	}

	@Test( priority = 2, enabled = true)
	public void name() throws InterruptedException, IOException {
		myNav_AWSCloud_Creation na = PageFactory.initElements(driver, myNav_AWSCloud_Creation.class);
		
		int nameCount = ExcelOp.getRowCount("AWS");
		System.out.println(nameCount);
		for (int row=1; row<=nameCount; row++) {
			testBase.namevalidation = ExcelOp.ReadExcelData("AWS", row, "name");			
			if (testBase.namevalidation.contains("NA"))
				break;
			else
				na.verifyName(testBase.namevalidation);
		}
	}
	@Test( priority = 3, enabled = true)
	public void description() throws InterruptedException, IOException {
		myNav_AWSCloud_Creation des = PageFactory.initElements(driver, myNav_AWSCloud_Creation.class);
		
		int descriptionCount = ExcelOp.getRowCount("AWS");
		for (int row=1; row<=descriptionCount; row++) {
			testBase.descriptionvalidation = ExcelOp.ReadExcelData("AWS", row, "description");			
			if (testBase.descriptionvalidation.contains("NA"))
				break;
			else
				des.verifyDescription(testBase.descriptionvalidation);
		}
	}
	
	@Test( priority = 4, enabled = true)
	public void accid() throws InterruptedException, IOException {
		myNav_AWSCloud_Creation aid = PageFactory.initElements(driver, myNav_AWSCloud_Creation.class);
		int accountCount = ExcelOp.getRowCount("AWS");
		for (int row=1; row<=accountCount; row++) {
			testBase.accountIdvalidation = ExcelOp.ReadExcelData("AWS", row, "accountid");		
			if (testBase.accountIdvalidation.contains("NA"))
				break;
			else
				aid.verifyAccountId(testBase.accountIdvalidation);
		}
	}
	
	@Test( priority = 5, enabled = true)
	public void env() throws InterruptedException, IOException {
		myNav_AWSCloud_Creation en = PageFactory.initElements(driver, myNav_AWSCloud_Creation.class);
		int envCount = ExcelOp.getRowCount("AWS");
		for (int row=1; row<=envCount; row++) {
			testBase.envalidation = ExcelOp.ReadExcelData("AWS", row, "environment");			
			if (testBase.envalidation.contains("NA"))
				break;
			else
				en.verifyEnvironment(testBase.envalidation);
		}
	}
	
	@Test( priority = 6, enabled = true)
	public void region() throws InterruptedException, IOException {
		myNav_AWSCloud_Creation re = PageFactory.initElements(driver, myNav_AWSCloud_Creation.class);
		
		int regionCount = ExcelOp.getRowCount("AWS");
		for (int row=1; row<=regionCount; row++) {
			testBase.regionvalidation = ExcelOp.ReadExcelData("AWS", row, "region");		
			if (testBase.regionvalidation.contains("NA"))
				break;
			else
				re.verifyRegion(testBase.regionvalidation);
		}
	}
	
	@Test( priority = 7, enabled = true)
	public void acckey() throws InterruptedException, IOException {
		myNav_AWSCloud_Creation acc = PageFactory.initElements(driver, myNav_AWSCloud_Creation.class);	
		int acckeyCount = ExcelOp.getRowCount("AWS");
		for (int row=1; row<=acckeyCount; row++) {
			testBase.accesskeyvalidation = ExcelOp.ReadExcelData("AWS", row, "accesskey");		
			if (testBase.accesskeyvalidation.contains("NA"))
				break;
			else
				acc.verifyAccesskey(testBase.accesskeyvalidation);
		}
	}
	
	@Test( priority = 8, enabled = true)
	public void seckey() throws InterruptedException, IOException {
		myNav_AWSCloud_Creation sec = PageFactory.initElements(driver, myNav_AWSCloud_Creation.class);
		int seckeyCount = ExcelOp.getRowCount("AWS");
		for (int row=1; row<=seckeyCount; row++) {
			testBase.secretkeyvalidation = ExcelOp.ReadExcelData("AWS", row, "secretkey");		
			if (testBase.secretkeyvalidation.contains("NA"))
				break;
			else
				sec.verifySecretkey(testBase.secretkeyvalidation);
		}
	}

	@AfterClass
	public void endDriver() {
		//driver.quit();
	}


}

package compliance.Functional;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Generic.TestBase.BrowserConfig;
import Generic.TestBase.CommonMethods;
import Generic.TestBase.ExcelOp;
import Generic.TestBase.testBase;
import compliance.PageObjMethods.Login;
import compliance.PageObjMethods.OrcheStratorAPIGitEndpointCreation;
import compliance.PageObjMethods.myNav_AWSCloud_Creation;

public class OrchestratorAPIGitEndpointCreation_Test extends testBase {

	public WebDriver driver = null;
	String parent;
	public String parentHandle = null;
	public static boolean classname;

	@BeforeClass
	public void initSetUp() throws IOException, InterruptedException {

		BrowserConfig.setDriver(browserType, appURL);
		driver=BrowserConfig.getDriver();
		ExcelOp.loadExcel("MyNav");
		try {
			if (driver == null)
				System.out.println("---Driver not found---");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		classname = true;

	}

	@Test( priority = 0, enabled = true)
	public void platformValidLogin() throws InterruptedException, IOException {
		Login login = PageFactory.initElements(driver, Login.class);
		login.devOpsPlatformLogin(testBase.getUsername(), testBase.getPassword());

	}

	@Test( priority = 1, enabled = true)
	public void Orchestrator_01() throws InterruptedException, IOException {
		OrcheStratorAPIGitEndpointCreation mpo = PageFactory.initElements(driver, OrcheStratorAPIGitEndpointCreation.class);
		mpo.MP_Orchestrator();
	}

	@Test( priority = 2, enabled = true)
	public void name() throws InterruptedException, IOException {
		OrcheStratorAPIGitEndpointCreation na = PageFactory.initElements(driver, OrcheStratorAPIGitEndpointCreation.class);

		int nameCount = ExcelOp.getRowCount("gitlab");
		//		System.out.println(nameCount);
		for (int row=1; row<=nameCount; row++) {
			testBase.namevalidation = ExcelOp.ReadExcelData("gitlab", row, "name");
			if (testBase.namevalidation.contains("NA"))
				break;
			else
				na.verifyname(testBase.namevalidation);
		}
	}
	@Test( priority = 3, enabled = true)
	public void token() throws InterruptedException, IOException {
		OrcheStratorAPIGitEndpointCreation na = PageFactory.initElements(driver, OrcheStratorAPIGitEndpointCreation.class);

		int nameCount = ExcelOp.getRowCount("gitlab");
		//		System.out.println(nameCount);
		for (int row=1; row<=nameCount; row++) {
			testBase.descriptionvalidation = ExcelOp.ReadExcelData("gitlab", row, "token");
			if (testBase.descriptionvalidation.contains("NA"))
				break;
			else
				na.verifytoken(testBase.descriptionvalidation);
		}
	}
	@Test( priority = 4, enabled = true)
	public void projectid() throws InterruptedException, IOException {
		OrcheStratorAPIGitEndpointCreation na = PageFactory.initElements(driver, OrcheStratorAPIGitEndpointCreation.class);

		int nameCount = ExcelOp.getRowCount("gitlab");
		//	System.out.println(nameCount);
		for (int row=1; row<=nameCount; row++) {
			testBase.accountIdvalidation = ExcelOp.ReadExcelData("gitlab", row, "projectid");
			if (testBase.accountIdvalidation.contains("NA"))
				break;
			else
				na.verifypid(testBase.accountIdvalidation);
		}
	}
	@Test( priority = 5, enabled = true)
	public void apiendpoint() throws InterruptedException, IOException {
		OrcheStratorAPIGitEndpointCreation na = PageFactory.initElements(driver, OrcheStratorAPIGitEndpointCreation.class);

		int nameCount = ExcelOp.getRowCount("gitlab");
		//	System.out.println(nameCount);
		for (int row=1; row<=nameCount; row++) {
			testBase.envalidation = ExcelOp.ReadExcelData("gitlab", row, "apiendpoint");
			if (testBase.envalidation.contains("NA"))
				break;
			else
				na.verifyapi(testBase.envalidation);
		}
	}
	@AfterClass
	public void endDriver() {
		//driver.quit();
	}


}

import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

// Simulated payment gateway
class PaymentGateway {
    private static final String API_KEY = "your_payment_api_key";

    public static boolean processPayment(String apiKey, String creditCardNumber, double amount) {
        // Verify the API key
        if (!apiKey.equals(API_KEY)) {
            System.out.println("Invalid API key.");
            return false;
        }

        // Simulate payment processing (you would replace this with a real payment gateway)
        System.out.println("Processing payment...");
        // Check if the credit card number is valid
        if (isValidCreditCard(creditCardNumber)) {
            System.out.println("Payment successful. Amount: $" + amount);
            return true;
        } else {
            System.out.println("Payment failed. Invalid credit card number.");
            return false;
        }
    }

    private static boolean isValidCreditCard(String creditCardNumber) {
        // Simulate a simple credit card validation check
        return creditCardNumber != null && creditCardNumber.length() == 16;
    }
}

// Security service for payment processing
class PaymentSecurityService {
    public static boolean verifyPayment(String apiKey, String creditCardNumber, double amount) {
        // Validate the API key and payment data
        if (apiKey == null || creditCardNumber == null || amount <= 0) {
            System.out.println("Invalid payment data.");
            return false;
        }

        // Verify the payment using the payment gateway
        return PaymentGateway.processPayment(apiKey, creditCardNumber, amount);
    }
}

public class OnlineBookStore {
    public static void main(String[] args) {
        // Simulated payment data
        String apiKey = "your_payment_api_key";
        String creditCardNumber = generateRandomCreditCardNumber();
        double amount = 50.0;

        // Verify the payment
        if (PaymentSecurityService.verifyPayment(apiKey, creditCardNumber, amount)) {
            // Process the order and provide access to the purchased books
            System.out.println("Order processed successfully.");
        } else {
            // Payment verification failed
            System.out.println("Payment verification failed. Please try again.");
        }
    }

    // Generate a random credit card number for simulation purposes
    private static String generateRandomCreditCardNumber() {
        SecureRandom random = new SecureRandom();
        byte[] numberBytes = new byte[16];
        random.nextBytes(numberBytes);
        return Base64.getEncoder().encodeToString(numberBytes);
    }
}

import java.util.HashMap;
import java.util.Map;

// Simulated database for user data
class UserDatabase {
    private static Map<String, String> customerDatabase = new HashMap<>();
    private static Map<String, String> sellerDatabase = new HashMap<>();
    
    static {
        // Add sample customer and seller data
        customerDatabase.put("customer1", "password1");
        sellerDatabase.put("seller1", "password1");
    }

    public static boolean validateCustomer(String username, String password) {
        return customerDatabase.containsKey(username) && customerDatabase.get(username).equals(password);
    }

    public static boolean validateSeller(String username, String password) {
        return sellerDatabase.containsKey(username) && sellerDatabase.get(username).equals(password);
    }
}

// Authentication and authorization service
class SecurityService {
    public static boolean authenticateCustomer(String username, String password) {
        if (UserDatabase.validateCustomer(username, password)) {
            // Successfully authenticated
            System.out.println("Customer logged in: " + username);
            return true;
        }
        return false;
    }

    public static boolean authenticateSeller(String username, String password) {
        if (UserDatabase.validateSeller(username, password)) {
            // Successfully authenticated
            System.out.println("Seller logged in: " + username);
            return true;
        }
        return false;
    }
}

public class OnlineBookStore {
    public static void main(String[] args) {
        // Simulated login process
        String customerUsername = "customer1";
        String customerPassword = "password1";

        String sellerUsername = "seller1";
        String sellerPassword = "password1";

        // Authenticate the customer
        if (SecurityService.authenticateCustomer(customerUsername, customerPassword)) {
            // Customer-specific actions
            // ...
        } else {
            // Customer login failed
            System.out.println("Customer login failed.");
        }

        // Authenticate the seller
        if (SecurityService.authenticateSeller(sellerUsername, sellerPassword)) {
            // Seller-specific actions
            // ...
        } else {
            // Seller login failed
            System.out.println("Seller login failed.");
        }
    }
}

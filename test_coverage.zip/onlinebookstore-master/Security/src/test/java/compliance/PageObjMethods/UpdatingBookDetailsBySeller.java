import java.util.HashMap;
import java.util.Map;

// Simulated book database
class BookDatabase {
    private static Map<String, Book> books = new HashMap<>();

    public static boolean bookExists(String bookId) {
        return books.containsKey(bookId);
    }

    public static void addBook(Book book) {
        books.put(book.getBookId(), book);
    }

    public static void updateBook(Book book) {
        books.put(book.getBookId(), book);
    }

    public static Book getBook(String bookId) {
        return books.get(bookId);
    }
}

// Book class to represent book details
class Book {
    private String bookId;
    private String title;
    private String author;
    private double price;

    public Book(String bookId, String title, String author, double price) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.price = price;
    }

    public String getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public double getPrice() {
        return price;
    }
}

// Seller database
class SellerDatabase {
    private static Map<String, String> sellers = new HashMap<>();

    static {
        // Simulated seller data
        sellers.put("seller1", "password1");
    }

    public static boolean sellerExists(String username) {
        return sellers.containsKey(username);
    }

    public static boolean validateSeller(String username, String password) {
        return sellerExists(username) && sellers.get(username).equals(password);
    }
}

// Security service for updating book details
class SellerBookUpdateSecurityService {
    public static boolean updateBookDetails(String sellerUsername, String password, Book updatedBook) {
        // Check if the seller exists and the password is valid
        if (SellerDatabase.validateSeller(sellerUsername, password)) {
            // Verify if the book exists
            if (BookDatabase.bookExists(updatedBook.getBookId())) {
                // Perform the update
                BookDatabase.updateBook(updatedBook);
                System.out.println("Book details updated successfully.");
                return true;
            } else {
                System.out.println("Book not found.");
            }
        } else {
            System.out.println("Seller authentication failed.");
        }
        return false;
    }
}

public class OnlineBookStore {
    public static void main(String[] args) {
        // Simulated seller update
        String sellerUsername = "seller1";
        String sellerPassword = "password1";

        Book updatedBook = new Book("book1", "Updated Title", "Updated Author", 39.99);

        // Attempt to update the book details securely
        if (SellerBookUpdateSecurityService.updateBookDetails(sellerUsername, sellerPassword, updatedBook)) {
            System.out.println("Book details updated successfully.");
        } else {
            System.out.println("Failed to update book details.");
        }
    }
}

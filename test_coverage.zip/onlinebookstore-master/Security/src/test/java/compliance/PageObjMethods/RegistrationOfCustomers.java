import java.util.HashMap;
import java.util.Map;

// Simulated user database
class UserDatabase {
    private static Map<String, String> users = new HashMap<>();

    public static boolean userExists(String username) {
        return users.containsKey(username);
    }

    public static void addUser(String username, String password) {
        users.put(username, password);
    }
}

// Registration service
class RegistrationService {
    public static boolean registerCustomer(String username, String password) {
        // Check if the username is already taken
        if (UserDatabase.userExists(username)) {
            System.out.println("Username is already taken.");
            return false;
        } else {
            // Store the user's information securely
            UserDatabase.addUser(username, password);
            System.out.println("Registration successful. Welcome, " + username + "!");
            return true;
        }
    }
}

// Security service for customer registration
class RegistrationSecurityService {
    public static boolean registerCustomerSecurely(String username, String password) {
        // Validate input data
        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            System.out.println("Invalid input data.");
            return false;
        }

        // Perform security checks, such as preventing common security vulnerabilities
        if (isInputValid(username) && isInputValid(password)) {
            return RegistrationService.registerCustomer(username, password);
        } else {
            System.out.println("Registration failed due to security checks.");
            return false;
        }
    }

    private static boolean isInputValid(String input) {
        // Simulate security checks for input data
        // You should implement input validation, such as checking for SQL injection, XSS, etc.
        return !input.matches(".*[<>&;\"].*");
    }
}

public class OnlineBookStore {
    public static void main(String[] args) {
        // Simulated user registration
        String username = "newcustomer";
        String password = "securePassword123";

        // Attempt to register the customer securely
        if (RegistrationSecurityService.registerCustomerSecurely(username, password)) {
            System.out.println("Customer registration successful.");
        } else {
            System.out.println("Customer registration failed.");
        }
    }
}

package compliance.PageObjMethods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

public class AddingBooksToCart {
    private WebDriver driver;

    public AddingBooksToCart(WebDriver driver) {
        this.driver = driver;
    }

    @FindBy(xpath = "//a[@id='addbook']")
    public WebElement addbooks;

    @FindBy(xpath = "//a[@id='bookName']")
    public WebElement bookname;

    @FindBy(xpath = "//a[@id='bookAuthor']")
    public WebElement bookauthor;

    @FindBy(xpath = "//input[@name='price']")
    public WebElement price;

    public void addingbooktocart() {
        // Click the "Add to Cart" button for a book
        addbooks.click();
        System.out.println("Able to add a book to the cart");
    }

    public void addingmultiplebooktocart() {
        // List of books to add to the cart (you can customize this list)
        List<String> booksToAdd = new ArrayList<>();
        booksToAdd.add("Book 1");
        booksToAdd.add("Book 2");
        booksToAdd.add("Book 3");

        // Iterate through the list and add each book to the cart
        for (String book : booksToAdd) {
            // Assuming each book has a unique identifier or link on the page
            WebElement bookLink = driver.findElement(By.linkText(book));
            bookLink.click();

            // Wait for the "Add to Cart" button to become clickable
            WebDriverWait wait = new WebDriverWait(driver, 10);
            WebElement addToCartButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("add-to-cart-button")));
            addToCartButton.click();

            // You can add further logic to handle pop-ups, confirmations, or any other steps specific to your application.
        }

        System.out.println("Able to add multiple books to the cart");
    }

    public void verifybooksincart() {
        // Assuming there's a cart element that displays the number of items
        WebElement cartElement = driver.findElement(By.xpath("//a[@id='cart']"));

        // Get the text indicating the number of items in the cart
        String cartText = cartElement.getText();

        // Assuming you have added books to the cart, you can check if the cart is not empty
        Assert.assertFalse(cartText.equals("0"));
        System.out.println("Able to view books added to the cart");
    }
}
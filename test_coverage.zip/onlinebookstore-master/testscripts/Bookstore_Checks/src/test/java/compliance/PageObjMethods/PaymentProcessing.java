package compliance.PageObjMethods;

public class PaymentProcessing {
	public void paymentProcessing() {
		System.setProperty("webdriver.chrome.driver", "path_to_chromedriver.exe");

        // Initialize the WebDriver
        WebDriver driver = new ChromeDriver();

        // Navigate to the online bookstore website
        driver.get("http://your-online-bookstore.com");

        // Perform some actions to add books to the cart, select shipping address, and proceed to payment
        // ...

        // Example: Clicking on a button to proceed to payment
        WebElement checkoutButton = driver.findElement(By.id("checkoutButton"));
        checkoutButton.click();

        // Enter payment details
        WebElement cardNumberInput = driver.findElement(By.id("cardNumber"));
        cardNumberInput.sendKeys("1234 5678 9012 3456");

        // Add more steps for filling out payment form fields (expiration date, CVV, etc.)

        // Submit the payment
        WebElement payButton = driver.findElement(By.id("payButton"));
        payButton.click();

        // Verify that the payment is successful
        WebElement confirmationMessage = driver.findElement(By.id("confirmationMessage"));
        String message = confirmationMessage.getText();
        if (message.contains("Payment successful")) {
            System.out.println("Payment was successful.");
        } else {
            System.out.println("Payment failed.");
        }

        // Close the browser
        driver.quit();

		
	}
}

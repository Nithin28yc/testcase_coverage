package compliance.PageObjMethods;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import java.time.Duration;

import com.relevantcodes.extentreports.LogStatus;

import Generic.TestBase.BrowserConfig;
import Generic.TestBase.CommonMethods;
import Generic.TestBase.testBase;

public class LoginFeatureForCustomersAndSellers extends testBase{
	
	private WebDriver driver = BrowserConfig.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	CommonMethods commonMethods = PageFactory.initElements(driver, CommonMethods.class);

	@FindBy(xpath = "//a[text()='Login']")
	public WebElement Loginpage;
	
	@FindBy(xpath = "//input[@id='userName']")
	public WebElement demoName;
	
	@FindBy(xpath = "//*[@id=\"theform\"]/table/tbody/tr[2]/td/a")
	public WebElement Adminlogin;
	
	@FindBy(xpath = "//a[normalize-space()='Not an Admin?, Click Here to Login as Customer']")
	public WebElement custLogin;

	@FindBy(xpath = "//input[@id='Password']")
	public WebElement demoPassword;

	@FindBy(xpath = "//div[@id='CaptchaDiv']")
	public WebElement captcha;
	
	
	@FindBy(xpath = "//input[@id='CaptchaInput']")
	public WebElement captchaField;
	
	@FindBy(xpath = "//input[@value=' Login as an User  ']")
	public WebElement logindemoButton;

	@FindBy(xpath = "//a[@id='cart']")
	public WebElement cartOption;
	
	@FindBy(xpath = "//a[@id='books']")
	public WebElement availableBookOption;
	

	@FindBy(xpath = "//td/p[contains(text(),'Welcome Demo, Happy Learning !!')]")
	public WebElement loginPageMsg;
	
	public void successfulLogin(String username,String password) throws InterruptedException {
		commonMethods.waitForPageToLoad();

		try {
			
			wait.until(ExpectedConditions.elementToBeClickable(Loginpage)).click();
			logger.log(LogStatus.INFO, "Clicking on Login Page");			
			System.out.println("Clicking on Login Page");
			commonMethods.waitForPageToLoad();
			
		try {
				JavascriptExecutor executor2 = (JavascriptExecutor) driver;	
				wait.until(ExpectedConditions.visibilityOf(demoName));
				
				logger.log(LogStatus.INFO, "Enter Username");	
			//wait.until(ExpectedConditions.elementToBeClickable(demoName)).click();
			
			System.out.println("Enter Username");
			//demoName.click();
			executor2.executeScript("arguments[0].click();", demoName);
			demoName.sendKeys(username);
			//	commonMethods.waitForPageToLoad();
			}
			catch  (Exception e) {
				logger.log(LogStatus.FAIL, "Platform is down");
				System.out.println(e);
			}
			
		
			wait.until(ExpectedConditions.visibilityOf(demoPassword));
			logger.log(LogStatus.INFO, "Enter Password");
			System.out.println("Enter password");
			demoPassword.click();
			demoPassword.sendKeys(password);
			//	commonMethods.waitForPageToLoad();

			String captchainput = captcha.getText();
			captchaField.sendKeys(captchainput);		
			
			logger.log(LogStatus.INFO, "Click on login button");
			System.out.println("Click on login button");
			logindemoButton.click();
		
			wait.until(ExpectedConditions.visibilityOf(loginPageMsg));
            logger.log(LogStatus.INFO, "Logged in as user successfully.");			
			System.out.println("Logged in as user successfully.");	
		} catch (Exception e) {
			logger.log(LogStatus.FAIL, "Platform is down");
			System.out.println(e);
			System.out.println("Platform is down");
			Assert.fail("Platform is down");
		}
	}
	public void unsuccessfulLogin() {
		logger.log(LogStatus.INFO, "Log in failed due to unsuccessful login");			
		System.out.println("Log in failed due to unsuccessful login");
	}
	public void forgetPassword() {
		logger.log(LogStatus.INFO, "Clicking on forget password to generate a new password");			
		System.out.println("Clicking on forget password to generate a new password");
	}
	
}
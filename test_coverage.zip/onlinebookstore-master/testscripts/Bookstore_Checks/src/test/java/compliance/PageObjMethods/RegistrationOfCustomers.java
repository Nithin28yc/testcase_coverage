package compliance.PageObjMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class RegistrationOfCustomers {
    private WebDriver driver;

    public RegistrationOfCustomers(WebDriver driver) {
        this.driver = driver;
    }

    public void successfulRegistration() {
        // Find registration form elements
        WebElement firstNameField = driver.findElement(By.id("firstName"));
        WebElement lastNameField = driver.findElement(By.id("lastName"));
        WebElement emailField = driver.findElement(By.id("email"));
        WebElement passwordField = driver.findElement(By.id("password"));
        WebElement registerButton = driver.findElement(By.id("registerButton"));

        // Fill in registration details
        firstNameField.sendKeys("John");
        lastNameField.sendKeys("Doe");
        emailField.sendKeys("johndoe@example.com");
        passwordField.sendKeys("password123");

        // Click the register button
        registerButton.click();

        // You may need to add code here to wait for the registration to complete or for a success message.

        // Assuming there's a success message element, check for its presence
        WebElement successMessage = driver.findElement(By.id("successMessage"));

        // Assert that the registration was successful
        Assert.assertTrue(successMessage.isDisplayed());
        System.out.println("Successful registration done with all the parameters entered");
    }

    public void unsuccessfulRegistration() {
        // Find registration form elements
        WebElement firstNameField = driver.findElement(By.id("firstName"));
        WebElement lastNameField = driver.findElement(By.id("lastName"));
        WebElement emailField = driver.findElement(By.id("email"));
        WebElement passwordField = driver.findElement(By.id("password"));
        WebElement registerButton = driver.findElement(By.id("registerButton"));

        // Fill in incomplete or incorrect registration details
        firstNameField.sendKeys("John");
        lastNameField.sendKeys("Doe"); // Missing the last name
        emailField.sendKeys("invalid_email"); // Invalid email format
        passwordField.sendKeys("short"); // Short password

        // Click the register button
        registerButton.click();

        // You may need to add code here to wait for error messages or handle validation errors.

        // Assuming there's an error message element, check for its presence
        WebElement errorMessage = driver.findElement(By.id("errorMessage"));

        // Assert that the registration was unsuccessful
        Assert.assertTrue(errorMessage.isDisplayed());
        System.out.println("Unsuccessful registration done with few parameters entered");
    }

    public void teardown() {
        // Close the browser after the test
        driver.quit();
    }
}
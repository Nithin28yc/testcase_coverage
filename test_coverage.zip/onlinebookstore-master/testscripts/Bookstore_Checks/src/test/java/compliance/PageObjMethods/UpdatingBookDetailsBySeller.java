package compliance.PageObjMethods;


import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import Generic.TestBase.BrowserConfig;
import Generic.TestBase.CommonMethods;
import Generic.TestBase.testBase;

public class UpdatingBookDetailsBySeller extends testBase{

	private WebDriver driver = BrowserConfig.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	CommonMethods commonMethods = PageFactory.initElements(driver, CommonMethods.class);

	@FindBy(xpath = "//a[text()='Login']")
	public WebElement Loginpage;

	@FindBy(xpath = "//*[@id=\"theform\"]/table/tbody/tr[2]/td/a")
	public WebElement Adminlogin;

	@FindBy(xpath = "//input[@id='userName']")
	public WebElement userName;

	@FindBy(xpath = "//input[@id='Password']")
	public WebElement userPassword;

	@FindBy(xpath = "//div[@id='CaptchaDiv']")
	public WebElement captcha;

	@FindBy(xpath = "//input[@value=' Login as an Admin  ']")
	public WebElement loginButton;

	@FindBy(xpath = "//a[@id='storebooks']")
	public WebElement storebooks;

	@FindBy(xpath = "/html/body/div/table/tbody/tr[1]/td[5]/form/button")
	public WebElement update;

	@FindBy(xpath = "//input[@id='bookQuantity']")
	public WebElement changequantity;

	@FindBy(xpath = "//input[@value=' Update Book ']")
	public WebElement updatebook;

	@FindBy(xpath = "/html/body/div/table/tbody/tr/td")
	public WebElement updatebookmsg;

	public boolean updatebookdetails(String username,String password) throws InterruptedException {
		commonMethods.waitForPageToLoad();

		try {
			wait.until(ExpectedConditions.visibilityOf(storebooks));
			logger.log(LogStatus.INFO, "Clicking on storebooks");			
			System.out.println("Clicking on storebooks");
			storebooks.click();

			wait.until(ExpectedConditions.visibilityOf(update));
			logger.log(LogStatus.INFO, "Clicking on update");			
			System.out.println("Clicking on update");
			update.click();

			wait.until(ExpectedConditions.visibilityOf(changequantity));
			logger.log(LogStatus.INFO, "Enter the change quantity");
			System.out.println("Enter the change quantity");
			changequantity.click();
			changequantity.clear();
			changequantity.sendKeys("25");

			wait.until(ExpectedConditions.visibilityOf(updatebook));
			logger.log(LogStatus.INFO, "Clicking on updatebook");			
			System.out.println("Clicking on updatebook");
			updatebook.click();
			try {
				wait.until(ExpectedConditions.visibilityOf(updatebookmsg));
				logger.log(LogStatus.PASS, "Book Detail Updated Successfully!");			
				System.out.println("Book Detail Updated Successfully!");
				return true;
			}
			catch (Exception e){
				logger.log(LogStatus.FAIL, "Book Detail did not Updated Successfully!");
			//	logger.log(LogStatus.INFO, "Book Detail did not Updated Successfully!");
				System.out.println("Book Detail did not Updated Successfully!");
				return false;
			}
		} catch (Exception e) {
			logger.log(LogStatus.FAIL, "Platform is down");
			System.out.println(e);
			System.out.println("Platform is down");
			Assert.fail("Platform is down");
			return false;
		}
	}


}

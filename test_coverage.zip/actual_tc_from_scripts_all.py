import csv
import os
import re
import openai
import pandas as pd

# Set your OpenAI API key
openai.api_type = "###API_TYPE###"
openai.api_base = "###API_BASE###"
openai.api_version = "###API_VERSION###"
openai.api_key = "###API_KEY###"

func_search_directory = 'onlinebookstore-master\/testscripts\Bookstore_Checks\src\/test\java\compliance\PageObjMethods'
perf_search_directory = 'onlinebookstore-master\\Performancescripts\\Gatling\\src\\test\\scala\\SIT_PERF'
sec_search_directory = 'onlinebookstore-master\\Security\\src\\test\\java\\compliance\\PageObjMethods'
func_folder_path = os.listdir(func_search_directory)
perf_folder_path = os.listdir(perf_search_directory)
sec_folder_path = os.listdir(sec_search_directory)
func_features_list = []
perf_features_list = []
sec_features_list = []

with open('test_coverage_all.csv', newline='') as file:
    csv_reader = csv.DictReader(file)   
    for row in csv_reader:
        if row['Type'] == 'Functional':
            func_features_list.append(row['Feature'])
        if row['Type'] == 'Performance':
            perf_features_list.append(row['Feature'])
        if row['Type'] == 'Security':
            sec_features_list.append(row['Feature'])

#Function to search for files
def func_search_files(directory, keyword):
    result = []
    for file in func_folder_path:
        if file.endswith('.java'):
            file_wo_ext = file.replace('.java','')
            if re.match(keyword, file_wo_ext, re.IGNORECASE) or keyword in file_wo_ext:
                # result.append(file_wo_ext)
                with open(func_search_directory+'\\'+file, 'r') as file:
                    code_snippet=file.read()
                response = openai.Completion.create(
                    engine="devops",
                    prompt=f"Give the list of covered functional test cases in plain language without test steps from the {code_snippet}\n\n",
                    max_tokens=700,  # Adjust the number of tokens as needed
                    temperature=0.7,  # Adjust the temperature for creativity
                )
                result.append(response.choices[0].text)
                # print(result)
    return result

func_file_results = {}
for func_feature in func_features_list:
    # print(re.sub(r'\s+', '', keyword))
    matches = func_search_files(func_search_directory, re.sub(r'\s+', '', func_feature))
    if matches:
        func_file_results[func_feature] = matches
print("Functional testcases:")
print(func_file_results)

def perf_search_files(directory, keyword):
    result = []
    for file in perf_folder_path:
        if file.endswith('.scala'):
            file_wo_ext = file.replace('.scala','')
            if re.match(keyword, file_wo_ext, re.IGNORECASE) or keyword in file_wo_ext:
                # result.append(file_wo_ext)
                with open(perf_search_directory+'\\'+file, 'r') as file:
                    code_snippet=file.read()
                response = openai.Completion.create(
                    engine="devops",
                    prompt=f"Give the list of covered performance test cases in plain language without test steps from the {code_snippet}\n\n",
                    max_tokens=700,  # Adjust the number of tokens as needed
                    temperature=0.7,  # Adjust the temperature for creativity
                )
                result.append(response.choices[0].text)
                # print(result)
    return result

perf_file_results = {}
for perf_feature in perf_features_list:
    # print(re.sub(r'\s+', '', keyword))
    matches = perf_search_files(perf_search_directory, re.sub(r'\s+', '', perf_feature))
    if matches:
        perf_file_results[perf_feature] = matches
print("Performance testcases:")
print(perf_file_results)

def sec_search_files(directory, keyword):
    result = []
    for file in sec_folder_path:
        if file.endswith('.java'):
            file_wo_ext = file.replace('.jva','')
            if re.match(keyword, file_wo_ext, re.IGNORECASE) or keyword in file_wo_ext:
                # result.append(file_wo_ext)
                with open(sec_search_directory+'\\'+file, 'r') as file:
                    code_snippet=file.read()
                response = openai.Completion.create(
                    engine="devops",
                    prompt=f"Give the list of covered security test cases in plain language without test steps from the {code_snippet}\n\n",
                    max_tokens=700,  # Adjust the number of tokens as needed
                    temperature=0.7,  # Adjust the temperature for creativity
                )
                result.append(response.choices[0].text)
                # print(result)
    return result

sec_file_results = {}
for sec_feature in sec_features_list:
    # print(re.sub(r'\s+', '', keyword))
    matches = sec_search_files(sec_search_directory, re.sub(r'\s+', '', sec_feature))
    if matches:
        sec_file_results[sec_feature] = matches
print("Security testcases:")
print(sec_file_results)


df = pd.read_csv('test_coverage_all.csv')
for index, row in df.iterrows():
    if row["Feature"] in func_file_results and row['Type'] == 'Functional':
        df.at[index, "Actual Test Cases"] = str(func_file_results[row["Feature"]])
    if row["Feature"] in perf_file_results and row['Type'] == 'Performance':
        df.at[index, "Actual Test Cases"] = str(perf_file_results[row["Feature"]])
    if row["Feature"] in sec_file_results and row['Type'] == 'Security':
        df.at[index, "Actual Test Cases"] = str(sec_file_results[row["Feature"]])
df.to_csv('test_coverage_all.csv', index=False)

print('successfully completed')
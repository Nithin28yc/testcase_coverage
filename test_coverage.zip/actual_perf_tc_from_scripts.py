import csv
import os
import re
import openai
import pandas as pd

# Set your OpenAI API key
openai.api_type = "###API_TYPE###"
openai.api_base = "###API_BASE###"
openai.api_version = "###API_VERSION###"
openai.api_key = "###API_KEY###"

search_directory = 'onlinebookstore-master\\Performancescripts\\Gatling\\src\\test\\scala\\SIT_PERF'
folder_path = os.listdir(search_directory)
features_list = []

with open('test_coverage_performance.csv', newline='') as file:
    csv_reader = csv.DictReader(file)   
    for row in csv_reader:
        features_list.append(row['Feature'])

# Function to search for files
def search_files(directory, keyword):
    result = []
    for file in folder_path:
        if file.endswith('.scala'):
            file_wo_ext = file.replace('.scala','')
            if re.match(keyword, file_wo_ext, re.IGNORECASE) or keyword in file_wo_ext:
                # result.append(file_wo_ext)
                with open(search_directory+'\\'+file, 'r') as file:
                    code_snippet=file.read()
                response = openai.Completion.create(
                    engine="devops",
                    prompt=f"Give the list of covered performance test cases {code_snippet} witout test steps from \n\n",
                    max_tokens=1000,  # Adjust the number of tokens as needed
                    temperature=1.0,  # Adjust the temperature for creativity
                )
                result.append(response.choices[0].text)
                # print(result)
    return result

file_results = {}
for feature in features_list:
    # print(re.sub(r'\s+', '', keyword))
    matches = search_files(search_directory, re.sub(r'\s+', '', feature))
    if matches:
        file_results[feature] = matches

print(file_results)

df = pd.read_csv('test_coverage_performance.csv')
for index, row in df.iterrows():
    if row["Feature"] in file_results:
        df.at[index, "Actual Test Cases"] = str(file_results[row["Feature"]])
df.to_csv('test_coverage_performance.csv', index=False)

print('successfully completed')
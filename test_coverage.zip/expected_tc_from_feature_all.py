import csv
import os
import openai
import json
import pandas as pd
# Set your OpenAI API key
openai.api_type = "###API_TYPE###"
openai.api_base = "###API_BASE###"
openai.api_version = "###API_VERSION###"
openai.api_key = "###API_KEY###"

features_list=[]
with open('test_coverage_all.csv', newline='') as file:
    csv_reader = csv.DictReader(file)   
    for row in csv_reader:
        features_list.append(row['Feature'])
tc_list = ""
all_features = features_list
TestCases = ['Functional', 'Performance', 'Security']
for eachtype in TestCases:
    for each_feature in all_features:
        response = openai.Completion.create(
            engine="devops",
            prompt=f""""Please generate a JSON structure with the following information:
                Feature: '{each_feature}'
                Expected Test Cases: Generate {eachtype} test cases, containing a list of test case descriptions.
                Expected Test Cases Count: Count of test cases from the above.
                Type: {eachtype}.
            """,
            # prompt=f""""Please generate a JSON structure with the following information:
            #     Feature: '{each_feature}'
            #     Expected Test Cases: Three sets of test cases, each containing a list of test case descriptions.
            #     Expected Test Cases Count: A list containing only the count of test cases for each type.
            #     Type: A list containing the types of test cases.(Functional, Performance, Security).
            # """,
            max_tokens=800,  # Adjust the number of tokens as needed
            temperature=0.2,  # Adjust the temperature for creativity
        )
        tc_list += response.choices[0].text + ", "
print(tc_list)
filepath = "expected_tc_from_feature_all.json"
with open(filepath, 'w') as file:
    file.write('[')
with open(filepath, 'a') as file:
    file.write(tc_list)

# Read the JSON data from the file
with open(filepath, 'r') as file:
    json_data = file.read()

# Remove the trailing comma (if it exists)
if json_data.endswith(', '):
    json_data = json_data[:-2]
    with open(filepath, 'w') as file:
        file.write(json_data)

with open(filepath, 'a') as file:
    file.write(']')

with open(filepath, encoding='utf-8') as inputfile:
    df = pd.read_json(inputfile)
        
df.to_csv('test_coverage_all.csv', encoding='utf-8', index=False)
print('successfully executed')
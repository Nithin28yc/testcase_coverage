import os
import openai
import pandas as pd

# Set your OpenAI API key
openai.api_type = "azure"
openai.api_base = "https://devopsvalidation.openai.azure.com/"
openai.api_version = "2023-09-15-preview"
openai.api_key = "27940702532b4623b2c59a296bfe484b"

code_snippet=''
features=""
# with open('C:\\Users\\keerthana.vijaykumar\\OneDrive - Accenture\\Desktop\\poc-tasks\\htmltojson\\testcoverage\\featuregenerated.txt', 'r') as file:
    # code_snippet=file.read()
path = 'onlinebookstore-master\src\main\java\servlets'
folder_path = os.listdir(path)
for file_name in folder_path:
    if file_name.endswith("BookServlet.java"):
        with open(path+'\\'+file_name, 'r') as file:
            code_snippet=file.read()
        response = openai.Completion.create(
                    engine="devops",
                    #prompt=f"Given the following code:\n\n{code_snippet}\n\nWrite the epic list\n",
                    prompt=f"Please identify the programming language of the below code. Ignore all commented lines of code. As a developer,explain the given code command by command and identify all the variables, loops, methods, functions, classes, database operations if any and explain without missing any logic and clearly in plain english for {code_snippet}\n",
                    #prompt=f"Given the following code:\n\n{code_snippet}\n\nGive the overview of application with the key features in 100 words using online bookstore\n",
                    max_tokens=2000,  # Adjust the number of tokens as needed
                    temperature=0,  # Adjust the temperature for creativity
            )
        codeexp = response.choices[0].text
        # print(file_name+":"+features)
        response1 = openai.Completion.create(
                    engine="devops",
                    #prompt=f"Given the following code:\n\n{code_snippet}\n\nWrite the epic list\n",
                    prompt=f"Get the summary in 100 words from{code_snippet}\n",
                    #prompt=f"Given the following code:\n\n{code_snippet}\n\nGive the overview of application with the key features in 100 words using online bookstore\n",
                    max_tokens=2000,  # Adjust the number of tokens as needed
                    temperature=0,  # Adjust the temperature for creativity
            )
        codeexp1 = response1.choices[0].text
        # # print(features)
        # with open('codeexplanation.txt', 'a') as file:
        #     file.write(features)
        codefile = file_name + codeexp1
      #  features.append(response.choices[0].text)
        features += codefile
print("overall summary for all files")
print(features)
print("----------------------------")
messages = []
prompt=f"""Give a descriptive 1000 words explanation document from {features} with clear structure that guides your audience. Begin by providing an overview of what the code does, why it was written, and how it fits into the project. Then, break down the code into smaller pieces and explain each one in a logical order. Use comments, headings, or diagrams to separate and label them. To show how the code works, use examples, scenarios, or demonstrations to demonstrate its tasks and how it handles inputs and outputs. When you're done, summarize your code by repeating the main points and outcomes of your code; additionally, highlight any challenges, limitations, or improvements."""
messages.append({'role':'user','content':prompt})
response = openai.ChatCompletion.create(
    engine="neww",
    messages = messages,
    #prompt=f"""Give a descriptive 1000 words explanation document from {features} with clear structure that guides your audience. Begin by providing an overview of what the code does, why it was written, and how it fits into the project. Then, break down the code into smaller pieces and explain each one in a logical order. Use comments, headings, or diagrams to separate and label them. To show how the code works, use examples, scenarios, or demonstrations to demonstrate its tasks and how it handles inputs and outputs. When you're done, summarize your code by repeating the main points and outcomes of your code; additionally, highlight any challenges, limitations, or improvements.""",
    #prompt=f"Give an overview of this {features} in 150 words\n",
    #prompt=f"""Please generate a JSON list from {features} with only the following information:
     #          Feature: 'Name of the feature'""",
    #max_tokens=3000,  # Adjust the number of tokens as needed
    temperature=0.7,  # Adjust the temperature for creativity
)
features_gen = response.choices[0].message['content']
print(features_gen)

# with open('feature_derived_from_code_new.json', 'w') as file:
#     file.write(features_gen)

# with open('feature_derived_from_code_new.json', encoding='utf-8') as inputfile:
#     df = pd.read_json(inputfile)

# df.to_csv('test_coverage_new.csv', encoding='utf-8', index=False)

print('successfully executed')
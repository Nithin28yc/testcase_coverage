import os
import openai
import pandas as pd
import csv

# Set your OpenAI API key
openai.api_type = "###API_TYPE###"
openai.api_base = "###API_BASE###"
openai.api_version = "###API_VERSION###"
openai.api_key = "###API_KEY###"

###########-----------Features derivation from code--------------##############
def features():
    code_snippet=''
    features=''
    path = 'onlinebookstore-master\src\main\java\servlets'
    folder_path = os.listdir(path)
    for file_name in folder_path:
        if file_name.endswith(".java"):
            with open(path+'\\'+file_name, 'r') as file:
                code_snippet=file.read()
            response = openai.Completion.create(
                        engine="devops",
                        prompt=f"Given the following code:\n\n{code_snippet}\n\nWrite the feature list in bullet points:\n",
                        max_tokens=2000,  # Adjust the number of tokens as needed
                        temperature=0,  # Adjust the temperature for creativity
                )
            features = response.choices[0].text

            # print(features)
            # with open('featuregenerated.txt', 'a') as file:
            #     file.write(test_scenarios_and_cases)

    response = openai.Completion.create(
        engine="devops",
    # prompt=f"From the following list:\n\n{features}\n\nGive only highlevel Features in proper json format:\n",
        prompt=f"""Please generate a JSON list from {features} with only the following information:
                Feature: 'Name of the feature'""",
        max_tokens=600,  # Adjust the number of tokens as needed
        temperature=0,  # Adjust the temperature for creativity
    )
    features_gen = response.choices[0].text
    print(features_gen)

    with open('feature_derived_from_code_new.json', 'w') as file:
        file.write(features_gen)

    with open('feature_derived_from_code_new.json', encoding='utf-8') as inputfile:
        df = pd.read_json(inputfile)

    df.to_csv('test_coverage_new.csv', encoding='utf-8', index=False)

    print('Features derived from code successfully')

features_section = features()

#########-----------------Expected testcases derivation from the features------------------------###########

def expectedtestcases():
    features_list=[]
    with open('test_coverage_all.csv', newline='') as file:
        csv_reader = csv.DictReader(file)   
        for row in csv_reader:
            features_list.append(row['Feature'])
    tc_list = ""
    all_features = features_list
    TestCases = ['Functional', 'Performance', 'Security']
    for eachtype in TestCases:
        for each_feature in all_features:
            response = openai.Completion.create(
                engine="devops",
                prompt=f""""Please generate a JSON structure with the following information:
                    Feature: '{each_feature}'
                    Expected Test Cases: Generate {eachtype} test cases, containing a list of test case descriptions.
                    Expected Test Cases Count: Count of test cases from the above.
                    Type: {eachtype}.
                """,
                max_tokens=800,  # Adjust the number of tokens as needed
                temperature=0.2,  # Adjust the temperature for creativity
            )
            tc_list += response.choices[0].text + ", "
    print(tc_list)
    filepath = "expected_tc_from_feature_all.json"
    with open(filepath, 'w') as file:
        file.write('[')
    with open(filepath, 'a') as file:
        file.write(tc_list)

    # Read the JSON data from the file
    with open(filepath, 'r') as file:
        json_data = file.read()

    # Remove the trailing comma (if it exists)
    if json_data.endswith(', '):
        json_data = json_data[:-2]
        with open(filepath, 'w') as file:
            file.write(json_data)

    with open(filepath, 'a') as file:
        file.write(']')

    with open(filepath, encoding='utf-8') as inputfile:
        df = pd.read_json(inputfile)
            
    df.to_csv('test_coverage_all.csv', encoding='utf-8', index=False)
    print('Expected testcases successfully executed')

expectedtestcases_section = expectedtestcases()

#######--------------------Manual/Automation testcase derivation --------------###########

def manual_testcase():
    func_features_list=[]
    with open('test_coverage_excelMapping.csv', newline='') as file:
        csv_reader = csv.DictReader(file)   
        for row in csv_reader:
            if row['Type'] == 'Functional':
                func_features_list.append(row['Feature'])

    messages=[]
    file_path = 'test_coverage_meaning.csv'
    df = pd.read_csv(file_path)
    grouped_test_cases = df.groupby('Feature')['Test Case Description'].apply(lambda x: x.tolist() if x.any() else ['']).reset_index()

    for expfeatures in func_features_list:
        for index, row in grouped_test_cases.iterrows():
            manfeature = row['Feature']
            test_cases = row['Test Case Description']
            prompt=f"""Is both the meanings of '{expfeatures}' and '{manfeature}' is same in plain english language? Give the Output in Yes or No format only"""
            messages.append({'role':'user','content':prompt})
            response2 = openai.ChatCompletion.create(
                engine="neww",
                messages = messages,
                #prompt=f"""Verify whether both the meanings of {res} and {res1} is same in plain language and describe the same thing of process. Dont compare with normal way. Give the Output in Yes or No""",
                #max_tokens=800,  # Adjust the number of tokens as needed
                temperature=0,  # Adjust the temperature for creativity
            )
            res2=response2.choices[0].message['content']
        #  print(res2)
            feature_test_cases = {}
            if "Yes" in res2:
                print(f"Feature: {expfeatures}")
                print(res2+ ": "+expfeatures+": "+manfeature)
                #for i, test_case in enumerate(test_cases):
                feature_test_cases[expfeatures]  = test_cases
                print(feature_test_cases )
                    #print(f" Test Case {i}: {test_case if test_case else ''}")  
                df = pd.read_csv('test_coverage_excelMapping.csv')
                # Create a new column 'Actual TC' if not already present
                if 'Actual Test Cases' not in df.columns:
                    df['Actual Test Cases'] = ''
                    print("Created a Actual Test Cases for first time in csv ")
                    df.to_csv('test_coverage_excelMapping.csv', index=False)
                # Loop through rows and organize test cases by feature
                for index, row in df.iterrows():
                    mainfeature = row['Feature']  
                    actual_tc = row['Actual Test Cases']
                    # Append test case to the corresponding feature
                    if mainfeature in feature_test_cases:
                        actual_tc = feature_test_cases[mainfeature] 
                    # else:
                    #     feature_test_cases[mainfeature] = [actual_tc]

                for keyfeature, test_cases in feature_test_cases.items():
                    actual_tc = ', '.join(test_cases)
                    df1 = pd.read_csv('test_coverage_excelMapping.csv')
                    for index, row in df1.iterrows():
                    #df.loc[df['Feature'] == mainfeature, 'Actual Test Cases'] = actual_tc
                        if row["Feature"] in keyfeature and row['Type'] == 'Functional':   
                            print(keyfeature)        
                            df.at[index, "Actual Test Cases"] = actual_tc
                df.to_csv('test_coverage_excelMapping.csv', index=False)
                print("updated to csv")
                print("------------------")
        print()
    print('Actual testcases successfully completed')

manual_testcase_section = manual_testcase()

#####--------------TestCase Coverage-----------############

def coverage_testcase():
    csv_file = 'test_coverage_excelMapping.csv'
    func_test_cases = {}
    perf_test_cases = {}
    sec_test_cases = {}

    with open(csv_file, newline='') as file:
        csv_reader = csv.DictReader(file)   
        for row in csv_reader:
            if row['Type'] == 'Functional':
                name = row['Feature']  # Use the header 'Name' as the key
                func_test_cases[name] = {
                    'Expected Test Cases': row['Expected Test Cases'],
                    'Actual Test Cases': row['Actual Test Cases'],
            }
            if row['Type'] == 'Performance':
                name = row['Feature']  # Use the header 'Name' as the key
                perf_test_cases[name] = {
                    'Expected Test Cases': row['Expected Test Cases'],
                    'Actual Test Cases': row['Actual Test Cases'],
            }
            if row['Type'] == 'Security':
                name = row['Feature']  # Use the header 'Name' as the key
                sec_test_cases[name] = {
                    'Expected Test Cases': row['Expected Test Cases'],
                    'Actual Test Cases': row['Actual Test Cases'],
            }
    ##For Functional TC coverage
    response = openai.Completion.create(
        engine="devops",
        prompt=f"""Generate a JSON structure with Uncovered Test Cases Count for each feature:
        Uncovered Test Cases Count: Comparing Expected Test Cases and Actual Test Cases from {func_test_cases} in plain language and give only the uncovered test cases count for each feature .\n\n""",
        max_tokens=800,  # Adjust the number of tokens as needed
        temperature=0.2,  # Adjust the temperature for creativity
    )
    actualfunc_tc_count = response.choices[0].text
    print(actualfunc_tc_count)
    with open('actual_tc_count_all.json', 'w') as file:
        file.write(actualfunc_tc_count)

    with open('actual_tc_count_all.json', 'r') as file:
        json_data = file.read()
    replacedjson_data = json_data.replace("'",'"')

    with open('actual_tc_count_all.json', 'w') as file:
        file.write(replacedjson_data)

    with open('actual_tc_count_all.json', encoding='utf-8') as inputfile:
        json_data = pd.read_json(inputfile)

    df = pd.read_csv('test_coverage_excelMapping.csv')
    for index, row in df.iterrows():
        if row['Type'] == 'Functional':
            if row["Feature"] in json_data:
                df.at[index, "Uncovered Test Cases Count"] = json_data[row["Feature"]]["Uncovered Test Cases Count"]
                df["Test Coverage in %"] = ((df["Expected Test Cases Count"] - df["Uncovered Test Cases Count"]) / df["Expected Test Cases Count"])*100
    df.to_csv('test_coverage_excelMapping.csv', index=False)

    print("TestCase Coverage Executed sucessfully")

coverage_testcase_section = coverage_testcase()
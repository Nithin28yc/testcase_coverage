import csv
import json
import os
import openai
import pandas as pd

# Set your OpenAI API key
openai.api_type = "###API_TYPE###"
openai.api_base = "###API_BASE###"
openai.api_version = "###API_VERSION###"
openai.api_key = "###API_KEY###"
# Specify the CSV file path
csv_file = 'test_coverage_excelMapping.csv'
func_test_cases = {}
perf_test_cases = {}
sec_test_cases = {}

with open(csv_file, newline='') as file:
    csv_reader = csv.DictReader(file)   
    for row in csv_reader:
        if row['Type'] == 'Functional':
            name = row['Feature']  # Use the header 'Name' as the key
            func_test_cases[name] = {
                'Expected Test Cases': row['Expected Test Cases'],
                'Actual Test Cases': row['Actual Test Cases'],
        }
        if row['Type'] == 'Performance':
            name = row['Feature']  # Use the header 'Name' as the key
            perf_test_cases[name] = {
                'Expected Test Cases': row['Expected Test Cases'],
                'Actual Test Cases': row['Actual Test Cases'],
        }
        if row['Type'] == 'Security':
            name = row['Feature']  # Use the header 'Name' as the key
            sec_test_cases[name] = {
                'Expected Test Cases': row['Expected Test Cases'],
                'Actual Test Cases': row['Actual Test Cases'],
        }
##For Functional TC coverage
response = openai.Completion.create(
    engine="devops",
    prompt=f"""Generate a JSON structure with Uncovered Test Cases Count for each feature:
    Uncovered Test Cases Count: Comparing Expected Test Cases and Actual Test Cases from {func_test_cases} in plain language and give only the uncovered test cases count for each feature .\n\n""",
    max_tokens=800,  # Adjust the number of tokens as needed
    temperature=0.2,  # Adjust the temperature for creativity
)
actualfunc_tc_count = response.choices[0].text
print(actualfunc_tc_count)
with open('actual_tc_count_all.json', 'w') as file:
    file.write(actualfunc_tc_count)

with open('actual_tc_count_all.json', 'r') as file:
    json_data = file.read()
replacedjson_data = json_data.replace("'",'"')

with open('actual_tc_count_all.json', 'w') as file:
    file.write(replacedjson_data)

with open('actual_tc_count_all.json', encoding='utf-8') as inputfile:
    json_data = pd.read_json(inputfile)

df = pd.read_csv('test_coverage_excelMapping.csv')
for index, row in df.iterrows():
    if row['Type'] == 'Functional':
        if row["Feature"] in json_data:
            df.at[index, "Uncovered Test Cases Count"] = json_data[row["Feature"]]["Uncovered Test Cases Count"]
            df["Test Coverage in %"] = ((df["Expected Test Cases Count"] - df["Uncovered Test Cases Count"]) / df["Expected Test Cases Count"])*100
df.to_csv('test_coverage_excelMapping.csv', index=False)

#For Performance TC coverage
response = openai.Completion.create(
    engine="devops",
    prompt=f"""Generate a JSON structure with Uncovered Test Cases Count for each feature:
    Uncovered Test Cases Count: Comparing Expected Test Cases and Actual Test Cases in plain language from {perf_test_cases} and give only the uncovered test cases count for each feature .\n\n""",
    max_tokens=800,  # Adjust the number of tokens as needed
    temperature=0.2,  # Adjust the temperature for creativity
)
actualperf_tc_count = response.choices[0].text
print(actualperf_tc_count)
with open('actual_tc_count_all.json', 'w') as file:
    file.write(actualperf_tc_count)

with open('actual_tc_count_all.json', 'r') as file:
    json_data = file.read()
replacedjson_data = json_data.replace("'",'"')

with open('actual_tc_count_all.json', 'w') as file:
    file.write(replacedjson_data)

with open('actual_tc_count_all.json', encoding='utf-8') as inputfile:
    json_data = pd.read_json(inputfile)

df = pd.read_csv('test_coverage_all.csv')
for index, row in df.iterrows():
    if row['Type'] == 'Performance':
        if row["Feature"] in json_data:
            df.at[index, "Uncovered Test Cases Count"] = json_data[row["Feature"]]["Uncovered Test Cases Count"]
            df["Test Coverage in %"] = ((df["Expected Test Cases Count"] - df["Uncovered Test Cases Count"]) / df["Expected Test Cases Count"])*100
df.to_csv('test_coverage_all.csv', index=False)

##For Securiq TC coverage
response = openai.Completion.create(
    engine="devops",
    prompt=f"""Generate a JSON structure with Uncovered Test Cases Count for each feature:
    Uncovered Test Cases Count: Comparing Expected Test Cases and Actual Test Cases in plain language from {sec_test_cases} and give only the uncovered test cases count for each feature .\n\n""",
    max_tokens=800,  # Adjust the number of tokens as needed
    temperature=0.2,  # Adjust the temperature for creativity
)
actualsec_tc_count = response.choices[0].text
print(actualsec_tc_count)

with open('actual_tc_count_all.json', 'w') as file:
    file.write(actualsec_tc_count)

with open('actual_tc_count_all.json', 'r') as file:
    json_data = file.read()
replacedjson_data = json_data.replace("'",'"')

with open('actual_tc_count_all.json', 'w') as file:
    file.write(replacedjson_data)

with open('actual_tc_count_all.json', encoding='utf-8') as inputfile:
    json_data = pd.read_json(inputfile)

df = pd.read_csv('test_coverage_all.csv')
for index, row in df.iterrows():
    if row['Type'] == 'Security':
        if row["Feature"] in json_data:
            df.at[index, "Uncovered Test Cases Count"] = json_data[row["Feature"]]["Uncovered Test Cases Count"]
            df["Test Coverage in %"] = ((df["Expected Test Cases Count"] - df["Uncovered Test Cases Count"]) / df["Expected Test Cases Count"])*100
df.to_csv('test_coverage_all.csv', index=False)

print('successfully completed')